from typing import *
import torch
import torch.nn as nn
import numpy as np
from PIL import Image
from .base import Pipeline
from . import samplers, rembg
from ..modules.sparse import SparseTensor
from ..modules import image_feature_extractor
from ..representations import Mesh, MeshWithVoxel

from .. import models

import gc
import os
import folder_paths
import trimesh
import o_voxel
import cumesh
import img3d_raster as dr  # our rasterizer (nvdiffrast is non-commercial)
import cv2
import flex_gemm
from flex_gemm.ops.grid_sample import grid_sample_3d

import random

from comfy.utils import ProgressBar

script_directory = os.path.dirname(os.path.abspath(__file__))

def build_pixal3d_image_cond_model(config: dict):
    from ..trainers.flow_matching.mixins.image_conditioned_proj import DinoV3ProjFeatureExtractor
    model = DinoV3ProjFeatureExtractor(**config)
    model.eval()
    return model

def build_pixal3d_mv_image_cond_model(config: dict):
    from ..trainers.flow_matching.mixins.image_conditioned_proj import DinoV3ProjMultiViewFeatureExtractor
    model = DinoV3ProjMultiViewFeatureExtractor(**config)
    model.eval()
    return model

def pil2tensor(image):
    return torch.from_numpy(np.array(image).astype(np.float32) / 255.0)[None,]

def seed_all(seed: int = 0):
    """
    Set random seeds of all components.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

class Trellis2ImageTo3DPipeline(Pipeline):
    """
    Pipeline for inferring Trellis2 image-to-3D models.

    Args:
        models (dict[str, nn.Module]): The models to use in the pipeline.
        sparse_structure_sampler (samplers.Sampler): The sampler for the sparse structure.
        shape_slat_sampler (samplers.Sampler): The sampler for the structured latent.
        tex_slat_sampler (samplers.Sampler): The sampler for the texture latent.
        sparse_structure_sampler_params (dict): The parameters for the sparse structure sampler.
        shape_slat_sampler_params (dict): The parameters for the structured latent sampler.
        tex_slat_sampler_params (dict): The parameters for the texture latent sampler.
        shape_slat_normalization (dict): The normalization parameters for the structured latent.
        tex_slat_normalization (dict): The normalization parameters for the texture latent.
        image_cond_model (Callable): The image conditioning model.
        rembg_model (Callable): The model for removing background.
        low_vram (bool): Whether to use low-VRAM mode.
    """
    # model_names_to_load = [
        # 'sparse_structure_flow_model',
        # 'sparse_structure_decoder',
        # 'shape_slat_flow_model_512',
        # 'shape_slat_flow_model_1024',
        # 'shape_slat_decoder',
        # 'tex_slat_flow_model_512',
        # 'tex_slat_flow_model_1024',
        # 'tex_slat_decoder',
    # ]

    def __init__(
        self,
        models: dict[str, nn.Module] = None,
        sparse_structure_sampler: samplers.Sampler = None,
        shape_slat_sampler: samplers.Sampler = None,
        tex_slat_sampler: samplers.Sampler = None,
        sparse_structure_sampler_params: dict = None,
        shape_slat_sampler_params: dict = None,
        tex_slat_sampler_params: dict = None,
        shape_slat_normalization: dict = None,
        tex_slat_normalization: dict = None,
        image_cond_model: Callable = None,
        rembg_model: Callable = None,
        low_vram: bool = True,
        default_pipeline_type: str = '1024_cascade',
    ):
        if models is None:
            return
        super().__init__(models)
        self.sparse_structure_sampler = sparse_structure_sampler
        self.shape_slat_sampler = shape_slat_sampler
        self.tex_slat_sampler = tex_slat_sampler
        self.sparse_structure_sampler_params = sparse_structure_sampler_params
        self.shape_slat_sampler_params = shape_slat_sampler_params
        self.tex_slat_sampler_params = tex_slat_sampler_params
        self.shape_slat_normalization = shape_slat_normalization
        self.tex_slat_normalization = tex_slat_normalization
        self.image_cond_model = image_cond_model
        self.rembg_model = rembg_model
        self._low_vram = low_vram
        self.default_pipeline_type = default_pipeline_type
        self.VGGT_model = None
        self.pbr_attr_layout = {
            'base_color': slice(0, 3),
            'metallic': slice(3, 4),
            'roughness': slice(4, 5),
            'alpha': slice(5, 6),
        }
        self._device = 'cpu'
        
        self.PIXAL3D_IMAGE_COND_CONFIGS = {
            "ss": {
                "model_name": "facebook/dinov3-vitl16-pretrain-lvd1689m",
                "image_size": 512,
                "grid_resolution": 16,
            },
            "shape_512": {
                "model_name": "facebook/dinov3-vitl16-pretrain-lvd1689m",
                "image_size": 512,
                "grid_resolution": 32,
                "use_naf_upsample": True,
                "naf_target_size": 512,
            },
            "shape_1024": {
                "model_name": "facebook/dinov3-vitl16-pretrain-lvd1689m",
                "image_size": 1024,
                "grid_resolution": 64,
                "use_naf_upsample": True,
                "naf_target_size": 512,
            },
            "tex_1024": {
                "model_name": "facebook/dinov3-vitl16-pretrain-lvd1689m",
                "image_size": 1024,
                "grid_resolution": 64,
                "use_naf_upsample": True,
                "naf_target_size": 1024,
            },
        }

        # Multi-view variants of the four stages. Same DINOv3 backbone and grid
        # resolutions as above -- only the extractor class and the fusion differ.
        # "average" keeps the fused feature shape identical to single-view, which is
        # why the *_mv denoisers need no architectural change.
        self.PIXAL3D_MV_IMAGE_COND_CONFIGS = {
            key: {**cfg, "multiview_fusion": "average"}
            for key, cfg in self.PIXAL3D_IMAGE_COND_CONFIGS.items()
        }
    def switch_samplers(self, sampler_type: str = "euler"):
        """Dynamically switches the sampler instances based on user selection."""
        self._sampler_prefix = "Euler"
        if sampler_type == "rk4":
            self._sampler_prefix = "RK4"
        elif sampler_type == "rk5":
            self._sampler_prefix = "RK5"
        elif sampler_type == "heun":
            self._sampler_prefix = "Heun"
            
        args = self._pretrained_args
        self.sparse_structure_sampler = getattr(samplers, f"Flow{self._sampler_prefix}GuidanceIntervalSampler")(**args['sparse_structure_sampler']['args'])
        self.shape_slat_sampler = getattr(samplers, f"Flow{self._sampler_prefix}GuidanceIntervalSampler")(**args['shape_slat_sampler']['args'])
        self.tex_slat_sampler = getattr(samplers, f"Flow{self._sampler_prefix}GuidanceIntervalSampler")(**args['tex_slat_sampler']['args'])        

    @property
    def low_vram(self) -> bool:
        return self._low_vram

    @low_vram.setter
    def low_vram(self, value: bool):
        self._low_vram = value
        for m in self.models.values():
            if hasattr(m, 'low_vram'):
                m.low_vram = value
        if hasattr(self, 'image_cond_model') and hasattr(self.image_cond_model, 'low_vram'):
            self.image_cond_model.low_vram = value

    def _cond_to(self, cond: dict, device: torch.device) -> dict:
        # Move only tensors; keep other items unchanged
        return {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in cond.items()}

    def _cond_cpu(self, cond: dict) -> dict:
        return {k: (v.cpu() if torch.is_tensor(v) else v) for k, v in cond.items()}

    def _cleanup_cuda(self):
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.synchronize()
            torch.cuda.empty_cache()

    @classmethod
    def from_pretrained(cls, path: str, config_file: str = "pipeline.json", keep_models_loaded = True, use_fp8 = False, use_reconviagen = False, isPixal3D = False, isPixal3DMV = False) -> "Trellis2ImageTo3DPipeline":
        """
        Load a pretrained model.

        Args:
            path (str): The path to the model. Can be either local path or a Hugging Face repository.
        """
        if use_reconviagen:
            config_file = "reconviagen_pipeline.json"
        elif use_fp8:
            config_file = "pipeline_fp8.json"
        elif isPixal3DMV:
            # The multi-view denoisers live next to the single-view ones under
            # ckpts/*_mv in the same repo; this config file is what points at them.
            config_file = "pipeline_mv.json"
            
        pipeline = super().from_pretrained(path, config_file)
        args = pipeline._pretrained_args

        pipeline.sparse_structure_sampler = getattr(samplers, args['sparse_structure_sampler']['name'])(**args['sparse_structure_sampler']['args'])
        pipeline.sparse_structure_sampler_params = args['sparse_structure_sampler']['params']

        pipeline.shape_slat_sampler = getattr(samplers, args['shape_slat_sampler']['name'])(**args['shape_slat_sampler']['args'])
        pipeline.shape_slat_sampler_params = args['shape_slat_sampler']['params']

        pipeline.tex_slat_sampler = getattr(samplers, args['tex_slat_sampler']['name'])(**args['tex_slat_sampler']['args'])
        pipeline.tex_slat_sampler_params = args['tex_slat_sampler']['params']

        pipeline.shape_slat_normalization = args['shape_slat_normalization']
        pipeline.tex_slat_normalization = args['tex_slat_normalization']

        #pipeline.image_cond_model = getattr(image_feature_extractor, args['image_cond_model']['name'])(**args['image_cond_model']['args'])
        #pipeline.rembg_model = getattr(rembg, args['rembg_model']['name'])(**args['rembg_model']['args'])
        
        pipeline.image_cond_model = None
        pipeline.rembg_model = None
        
        pipeline.low_vram = args.get('low_vram', True)
        pipeline.default_pipeline_type = args.get('default_pipeline_type', '1024_cascade')
        pipeline.pbr_attr_layout = {
            'base_color': slice(0, 3),
            'metallic': slice(3, 4),
            'roughness': slice(4, 5),
            'alpha': slice(5, 6),
        }
        pipeline._device = 'cpu'
        pipeline.path = path
        pipeline.keep_models_loaded = keep_models_loaded
        pipeline.last_processing = ''
        pipeline.use_fp8 = use_fp8
        pipeline.isPixal3D = isPixal3D
        pipeline.isPixal3DMV = isPixal3DMV

        if not isPixal3D:
            pipeline._pretrained_args['models']['sparse_structure_decoder'] = os.path.join(folder_paths.models_dir,"microsoft","TRELLIS-image-large","ckpts","ss_dec_conv3d_16l8_fp16")
            
        facebook_model_path = os.path.join(folder_paths.models_dir,"facebook","dinov3-vitl16-pretrain-lvd1689m")
        pipeline._pretrained_args['image_cond_model']['args']['model_name'] = facebook_model_path           
    
        pipeline.PIXAL3D_IMAGE_COND_CONFIGS["ss"]["model_name"] = facebook_model_path
        pipeline.PIXAL3D_IMAGE_COND_CONFIGS["shape_512"]["model_name"] = facebook_model_path
        pipeline.PIXAL3D_IMAGE_COND_CONFIGS["shape_1024"]["model_name"] = facebook_model_path
        pipeline.PIXAL3D_IMAGE_COND_CONFIGS["tex_1024"]["model_name"] = facebook_model_path

        for _cfg in pipeline.PIXAL3D_MV_IMAGE_COND_CONFIGS.values():
            _cfg["model_name"] = facebook_model_path

        try:
            from mmgp import safetensors2 as _mmgp_st2
            if 'C64' not in _mmgp_st2._map_to_dtype:
                _mmgp_st2._map_to_dtype['C64'] = torch.complex64
                _mmgp_st2._map_to_dtype['C128'] = torch.complex128
                print("[Pixal3D] Patched mmgp.safetensors2._map_to_dtype with C64/C128")
        except (ImportError, AttributeError):
            print('mmgp not installed')
            # mmgp not installed (comfy_env worker / non-Desktop ComfyUI) — no patch needed.
            pass

        return pipeline
            
    def load_moge_model(self):
        if hasattr(self,'moge_model') and self.moge_model is not None:
            return self.moge_model
        
        model_name = "Ruicheng/moge-2-vitl"
        moge_model_path = os.path.join(folder_paths.models_dir, "Ruicheng","moge-2-vitl")
        
        if not os.path.exists(moge_model_path):
            print(f"Downloading MoGe model to: {moge_model_path}")
            from huggingface_hub import snapshot_download
            snapshot_download(
                repo_id=model_name,
                local_dir=moge_model_path,
                local_dir_use_symlinks=False,
            )
        
        moge_model_path = os.path.join(moge_model_path,'model.pt')
        
        print('Loading MoGe model ...')
        from moge.model.v2 import MoGeModel
        self.moge_model = MoGeModel.from_pretrained(moge_model_path).to(self.device)
        self.moge_model.eval()

    def unload_moge_model(self):
        if hasattr(self,'moge_model') and self.moge_model is not None:
            del self.moge_model
            self.moge_model = None
            self._cleanup_cuda() 
        
    def load_pixal3d_image_cond_ss(self):    
        if hasattr(self,'pixal3d_image_cond_ss') and self.pixal3d_image_cond_ss is not None:
            return self.pixal3d_image_cond_ss
        
        print('Loading Pixal3D Image Cond SS Model ...')
        model = build_pixal3d_image_cond_model(self.PIXAL3D_IMAGE_COND_CONFIGS["ss"])
        self.pixal3d_image_cond_ss = model
        return model
        
    def unload_pixal3d_image_cond_ss(self):
        if hasattr(self,'pixal3d_image_cond_ss') and self.pixal3d_image_cond_ss is not None:
            del self.pixal3d_image_cond_ss
            self.pixal3d_image_cond_ss = None
            self._cleanup_cuda() 
            
    def load_pixal3d_image_cond_shape_512(self):    
        if hasattr(self,'pixal3d_image_cond_shape_512') and self.pixal3d_image_cond_shape_512 is not None:
            return self.pixal3d_image_cond_shape_512
        
        print('Loading Pixal3D Image Cond Shape 512 Model ...')
        model = build_pixal3d_image_cond_model(self.PIXAL3D_IMAGE_COND_CONFIGS["shape_512"])
        self.pixal3d_image_cond_shape_512 = model
        return model
        
    def unload_pixal3d_image_cond_shape_512(self):
        if hasattr(self,'pixal3d_image_cond_shape_512') and self.pixal3d_image_cond_shape_512 is not None:
            del self.pixal3d_image_cond_shape_512
            self.pixal3d_image_cond_shape_512 = None
            self._cleanup_cuda() 
            
    def load_pixal3d_image_cond_shape_1024(self):    
        if hasattr(self,'pixal3d_image_cond_shape_1024') and self.pixal3d_image_cond_shape_1024 is not None:
            return self.pixal3d_image_cond_shape_1024
        
        print('Loading Pixal3D Image Cond Shape 1024 Model ...')
        model = build_pixal3d_image_cond_model(self.PIXAL3D_IMAGE_COND_CONFIGS["shape_1024"])
        self.pixal3d_image_cond_shape_1024 = model
        return model
        
    def unload_pixal3d_image_cond_shape_1024(self):
        if hasattr(self,'pixal3d_image_cond_shape_1024') and self.pixal3d_image_cond_shape_1024 is not None:
            del self.pixal3d_image_cond_shape_1024
            self.pixal3d_image_cond_shape_1024 = None
            self._cleanup_cuda() 

    def load_pixal3d_image_cond_tex_1024(self):    
        if hasattr(self,'pixal3d_image_cond_tex_1024') and self.pixal3d_image_cond_tex_1024 is not None:
            return self.pixal3d_image_cond_tex_1024
        
        print('Loading Pixal3D Image Cond Tex 1024 Model ...')
        model = build_pixal3d_image_cond_model(self.PIXAL3D_IMAGE_COND_CONFIGS["tex_1024"])
        self.pixal3d_image_cond_tex_1024 = model
        return model
        
    def unload_pixal3d_image_cond_tex_1024(self):
        if hasattr(self,'pixal3d_image_cond_tex_1024') and self.pixal3d_image_cond_tex_1024 is not None:
            del self.pixal3d_image_cond_tex_1024
            self.pixal3d_image_cond_tex_1024 = None
            self._cleanup_cuda()

    # ---- Pixal3D multi-view image cond models (DinoV3ProjMultiViewFeatureExtractor) ----

    def _load_pixal3d_mv_image_cond(self, stage: str):
        attr = f'pixal3d_mv_image_cond_{stage}'
        model = getattr(self, attr, None)
        if model is not None:
            return model

        print(f'Loading Pixal3D MultiView Image Cond {stage} Model ...')
        model = build_pixal3d_mv_image_cond_model(self.PIXAL3D_MV_IMAGE_COND_CONFIGS[stage])
        setattr(self, attr, model)
        return model

    def _unload_pixal3d_mv_image_cond(self, stage: str):
        attr = f'pixal3d_mv_image_cond_{stage}'
        if getattr(self, attr, None) is not None:
            setattr(self, attr, None)
            self._cleanup_cuda()

    def load_pixal3d_mv_image_cond_ss(self):
        return self._load_pixal3d_mv_image_cond('ss')

    def unload_pixal3d_mv_image_cond_ss(self):
        self._unload_pixal3d_mv_image_cond('ss')

    def load_pixal3d_mv_image_cond_shape_512(self):
        return self._load_pixal3d_mv_image_cond('shape_512')

    def unload_pixal3d_mv_image_cond_shape_512(self):
        self._unload_pixal3d_mv_image_cond('shape_512')

    def load_pixal3d_mv_image_cond_shape_1024(self):
        return self._load_pixal3d_mv_image_cond('shape_1024')

    def unload_pixal3d_mv_image_cond_shape_1024(self):
        self._unload_pixal3d_mv_image_cond('shape_1024')

    def load_pixal3d_mv_image_cond_tex_1024(self):
        return self._load_pixal3d_mv_image_cond('tex_1024')

    def unload_pixal3d_mv_image_cond_tex_1024(self):
        self._unload_pixal3d_mv_image_cond('tex_1024')
        
    def load_sparse_structure_model(self):        
        if self.models['sparse_structure_flow_model'] is None:
            print('Loading Sparse Structure model ...')
            self.models['sparse_structure_flow_model'] = models.from_pretrained(f"{self.path}/{self._pretrained_args['models']['sparse_structure_flow_model']}")
            self.models['sparse_structure_flow_model'].eval()
            self.models['sparse_structure_flow_model'].to(self._device)
        
        if self.models['sparse_structure_decoder'] is None:  
            if self.isPixal3D:
                self.models['sparse_structure_decoder'] = models.from_pretrained(f"{self.path}/{self._pretrained_args['models']['sparse_structure_decoder']}")
            else:
                self.models['sparse_structure_decoder'] = models.from_pretrained(self._pretrained_args['models']['sparse_structure_decoder'])
            self.models['sparse_structure_decoder'].eval()        
            self.models['sparse_structure_decoder'].to(self._device)
            if hasattr(self.models['sparse_structure_decoder'], 'low_vram'):
                self.models['sparse_structure_decoder'].low_vram = self.low_vram
                
    def load_sparse_structure_vggt_model(self):        
        if self.models['sparse_structure_flow_vggt_model'] is None:
            print('Loading Sparse Structure VGGT model ...')
            self.models['sparse_structure_flow_vggt_model'] = models.from_pretrained(f"{self.path}/{self._pretrained_args['models']['sparse_structure_flow_vggt_model']}")
            self.models['sparse_structure_flow_vggt_model'].eval()
            self.models['sparse_structure_flow_vggt_model'].to(self._device)
        
        if self.models['sparse_structure_decoder'] is None:            
            self.models['sparse_structure_decoder'] = models.from_pretrained(self._pretrained_args['models']['sparse_structure_decoder'])
            self.models['sparse_structure_decoder'].eval()        
            self.models['sparse_structure_decoder'].to(self._device)
            if hasattr(self.models['sparse_structure_decoder'], 'low_vram'):
                self.models['sparse_structure_decoder'].low_vram = self.low_vram                
                
    def unload_sparse_structure_vggt_model(self):
        if self.models['sparse_structure_flow_vggt_model']:
            del self.models['sparse_structure_flow_vggt_model']
            self.models['sparse_structure_flow_vggt_model'] = None            
            
        if self.models['sparse_structure_decoder']:
            del self.models['sparse_structure_decoder']
            self.models['sparse_structure_decoder'] = None
        
        self._cleanup_cuda()                
                
    def load_sparse_structure_vggt_cond(self):        
        if self.models['sparse_structure_vggt_cond'] is None:
            print('Loading Sparse Structure VGGT cond ...')
            self.models['sparse_structure_vggt_cond'] = models.from_pretrained(f"{self.path}/{self._pretrained_args['models']['sparse_structure_vggt_cond']}")
            self.models['sparse_structure_vggt_cond'].eval()
            self.models['sparse_structure_vggt_cond'].to(self._device)  

    def unload_sparse_structure_vggt_cond(self):
        if self.models['sparse_structure_vggt_cond']:
            del self.models['sparse_structure_vggt_cond']
            self.models['sparse_structure_vggt_cond'] = None
            self._cleanup_cuda() 
    
    def unload_sparse_structure_model(self):
        if self.models['sparse_structure_flow_model']:
            del self.models['sparse_structure_flow_model']
            self.models['sparse_structure_flow_model'] = None            
            
        if self.models['sparse_structure_decoder']:
            del self.models['sparse_structure_decoder']
            self.models['sparse_structure_decoder'] = None
        
        self._cleanup_cuda()
            
    def load_image_cond_model(self):
        if self.image_cond_model is None:
            print('Loading Image Cond model ...')
            self.image_cond_model = getattr(image_feature_extractor, self._pretrained_args['image_cond_model']['name'])(**self._pretrained_args['image_cond_model']['args'])
            self.image_cond_model.to(self._device)
            
    def unload_image_cond_model(self):
        if self.image_cond_model is not None:
            del self.image_cond_model
            self.image_cond_model = None            
            self._cleanup_cuda()
            
    def load_shape_slat_flow_model_512(self):        
        if self.models['shape_slat_flow_model_512'] is None:
            print('Loading Shape Slat Flow 512 model ...')
            self.models['shape_slat_flow_model_512'] = models.from_pretrained(f"{self.path}/{self._pretrained_args['models']['shape_slat_flow_model_512']}")
            self.models['shape_slat_flow_model_512'].eval()
            self.models['shape_slat_flow_model_512'].to(self._device)
            
    def unload_shape_slat_flow_model_512(self):
        if self.models['shape_slat_flow_model_512'] is not None:
            del self.models['shape_slat_flow_model_512']
            self.models['shape_slat_flow_model_512'] = None
            self._cleanup_cuda()
            
    def load_tex_slat_flow_model_512(self):        
        if self.models['tex_slat_flow_model_512'] is None:
            print('Loading Texture Slat Flow 512 model ...')
            self.models['tex_slat_flow_model_512'] = models.from_pretrained(f"{self.path}/{self._pretrained_args['models']['tex_slat_flow_model_512']}")
            self.models['tex_slat_flow_model_512'].eval()
            self.models['tex_slat_flow_model_512'].to(self._device)          

    def unload_tex_slat_flow_model_512(self):
        if self.models['tex_slat_flow_model_512'] is not None:
            del self.models['tex_slat_flow_model_512']
            self.models['tex_slat_flow_model_512'] = None
            self._cleanup_cuda()

    def load_tex_slat_decoder(self):        
        if self.models['tex_slat_decoder'] is None:
            print('Loading Texture Slat decoder model ...')
            self.models['tex_slat_decoder'] = models.from_pretrained(f"{self.path}/{self._pretrained_args['models']['tex_slat_decoder']}")
            self.models['tex_slat_decoder'].eval()
            self.models['tex_slat_decoder'].to(self._device)
            if hasattr(self.models['tex_slat_decoder'], 'low_vram'):
                self.models['tex_slat_decoder'].low_vram = self.low_vram

    def unload_tex_slat_decoder(self):
        if self.models['tex_slat_decoder'] is not None:
            del self.models['tex_slat_decoder']
            self.models['tex_slat_decoder'] = None
            self._cleanup_cuda()
            
    def load_shape_slat_decoder(self):        
        if self.models['shape_slat_decoder'] is None:
            print('Loading Shape Slat decoder model ...')
            self.models['shape_slat_decoder'] = models.from_pretrained(f"{self.path}/{self._pretrained_args['models']['shape_slat_decoder']}")
            self.models['shape_slat_decoder'].eval()
            self.models['shape_slat_decoder'].to(self._device)
            if hasattr(self.models['shape_slat_decoder'], 'low_vram'):
                self.models['shape_slat_decoder'].low_vram = self.low_vram

    def unload_shape_slat_decoder(self):
        if self.models['shape_slat_decoder'] is not None:
            del self.models['shape_slat_decoder']
            self.models['shape_slat_decoder'] = None
            self._cleanup_cuda()

    def load_shape_slat_flow_model_1024(self):        
        if self.models['shape_slat_flow_model_1024'] is None:
            print('Loading Shape Slat Flow 1024 model ...')
            self.models['shape_slat_flow_model_1024'] = models.from_pretrained(f"{self.path}/{self._pretrained_args['models']['shape_slat_flow_model_1024']}")
            self.models['shape_slat_flow_model_1024'].eval()
            self.models['shape_slat_flow_model_1024'].to(self._device)           

    def unload_shape_slat_flow_model_1024(self):
        if self.models['shape_slat_flow_model_1024'] is not None:
            del self.models['shape_slat_flow_model_1024']
            self.models['shape_slat_flow_model_1024'] = None
            self._cleanup_cuda()

    def load_tex_slat_flow_model_1024(self):        
        if self.models['tex_slat_flow_model_1024'] is None:
            print('Loading Texture Slat Flow 1024 model ...')
            self.models['tex_slat_flow_model_1024'] = models.from_pretrained(f"{self.path}/{self._pretrained_args['models']['tex_slat_flow_model_1024']}")
            self.models['tex_slat_flow_model_1024'].eval()
            self.models['tex_slat_flow_model_1024'].to(self._device)                   

    def unload_tex_slat_flow_model_1024(self):
        if self.models['tex_slat_flow_model_1024'] is not None:
            del self.models['tex_slat_flow_model_1024']
            self.models['tex_slat_flow_model_1024'] = None
            self._cleanup_cuda()

    def _shape_slat_encoder_path(self) -> str:
        """
        Resolve the shape VAE encoder, falling back to the TRELLIS.2-4B copy.

        Pixal3D ships the shape decoder but no encoder, so encoding an existing mesh
        (Mesh Texturing) has nothing to load from its own ckpts. Its shape VAE is the
        TRELLIS.2-4B one -- shape_dec_next_dc_f16c32_fp16 is byte-identical in both
        repos -- so the TRELLIS.2-4B encoder is the matching half and puts the mesh in
        the very latent space Pixal3D's denoisers were trained on.
        """
        local = f"{self.path}/ckpts/shape_enc_next_dc_f16c32_fp16"
        if os.path.exists(f"{local}.safetensors"):
            return local

        trellis2_dir = os.path.join(folder_paths.models_dir, 'microsoft', 'TRELLIS.2-4B')
        fallback = os.path.join(trellis2_dir, 'ckpts', 'shape_enc_next_dc_f16c32_fp16')
        if not os.path.exists(f"{fallback}.safetensors"):
            print('Shape Slat Encoder not found. Downloading it from microsoft/TRELLIS.2-4B ...')
            from huggingface_hub import hf_hub_download
            os.environ.setdefault("HF_HUB_ENABLE_HF_TRANSFER", "1")
            for ext in ('json', 'safetensors'):
                hf_hub_download(
                    repo_id='microsoft/TRELLIS.2-4B',
                    filename=f'ckpts/shape_enc_next_dc_f16c32_fp16.{ext}',
                    local_dir=trellis2_dir,
                    local_dir_use_symlinks=False,
                )
        return fallback

    def load_shape_slat_encoder(self):        
        if self.models['shape_slat_encoder'] is None:
            print('Loading Shape Slat Encoder model ...')
            if getattr(self, 'use_fp8', False):
                self.models['shape_slat_encoder'] = models.from_pretrained(f"{self.path}/ckpts_fp8/shape_enc_next_dc_f16c32_fp8") 
            else:           
                self.models['shape_slat_encoder'] = models.from_pretrained(self._shape_slat_encoder_path())
            self.models['shape_slat_encoder'].eval()
            self.models['shape_slat_encoder'].to(self._device)
            if hasattr(self.models['shape_slat_encoder'], 'low_vram'):
                self.models['shape_slat_encoder'].low_vram = self.low_vram

    def unload_shape_slat_encoder(self):
        if self.models['shape_slat_encoder'] is not None:
            del self.models['shape_slat_encoder']
            self.models['shape_slat_encoder'] = None
            self._cleanup_cuda()      

    def to(self, device: torch.device) -> None:
        self._device = device
        if not self.low_vram:
            super().to(device)
            if self.image_cond_model is not None:
                self.image_cond_model.to(device)
            if self.rembg_model is not None:
                self.rembg_model.to(device)

    # =========================================================================
    # Proj mode condition building
    # =========================================================================
    
    @torch.no_grad()
    def get_proj_cond_ss(
        self,
        image: list,
        camera_angle_x: float = 0.8575560450553894,
        distance: float = 2.0,
        mesh_scale: float = 1.0,
        image_cond_model = None
    ) -> dict:
        """
        Get proj conditioning for sparse structure stage.

        Args:
            image: List of PIL images.
            camera_angle_x: Camera horizontal FOV in radians.
            distance: Camera distance.
            mesh_scale: Mesh scale.

        Returns:
            dict with 'cond' and 'neg_cond', each containing {'global': ..., 'proj': ...}
        """
        print('Getting Proj Image Cond ...')
        device = self.device        
        #image_cond_model = self.image_cond_model
        if self.low_vram:
            image_cond_model.to(device)
        cam_angle = torch.tensor([camera_angle_x], device=device)
        dist_tensor = torch.tensor([distance], device=device)
        scale_tensor = torch.tensor([mesh_scale], device=device)
        z_global, z_proj = image_cond_model(
            image, camera_angle_x=cam_angle, distance=dist_tensor, mesh_scale=scale_tensor,
        )
        if self.low_vram:
            image_cond_model.cpu()
        return {
            'cond': {'global': z_global, 'proj': z_proj},
            'neg_cond': {'global': torch.zeros_like(z_global), 'proj': torch.zeros_like(z_proj)},
        }

    @torch.no_grad()
    def get_proj_cond_shape(
        self,
        image_cond_model: nn.Module,
        image: list,
        coords: torch.Tensor,
        camera_angle_x: float = 0.8575560450553894,
        distance: float = 2.0,
        mesh_scale: float = 1.0,
        grid_resolution_override: int = None,
    ) -> dict:
        """
        Get proj conditioning for shape/texture stages (sparse-token aligned).

        Args:
            image_cond_model: The proj image cond model for this stage.
            image: List of PIL images.
            coords: Sparse structure coordinates [N, 4] (batch_idx, x, y, z).
            camera_angle_x: Camera horizontal FOV in radians.
            distance: Camera distance.
            mesh_scale: Mesh scale.
            grid_resolution_override: Override the grid resolution if not None.

        Returns:
            dict with 'cond' and 'neg_cond', each containing {'global': ..., 'proj': SparseTensor}
        """
        print('Getting Projected Image Cond ...')
        device = self.device
        if self.low_vram:
            image_cond_model.to(device)

        orig_grid_res = image_cond_model.grid_resolution
        if grid_resolution_override is not None and grid_resolution_override != orig_grid_res:
            image_cond_model.grid_resolution = grid_resolution_override
            image_cond_model.proj_grid = image_cond_model.proj_grid.__class__(
                grid_resolution=grid_resolution_override,
                image_resolution=image_cond_model.proj_grid.image_resolution,
            ).to(device)

        B = 1
        cam_angle = torch.tensor([camera_angle_x], device=device)
        dist_tensor = torch.tensor([distance], device=device)
        scale_tensor = torch.tensor([mesh_scale], device=device)
        z_global, z_proj = image_cond_model(
            image, camera_angle_x=cam_angle, distance=dist_tensor, mesh_scale=scale_tensor,
        )
        grid_res = image_cond_model.grid_resolution
        z_proj_grid = z_proj.reshape(B, grid_res, grid_res, grid_res, -1)
        batch_indices = coords[:, 0].long()
        x_coords = coords[:, 1].long()
        y_coords = coords[:, 2].long()
        z_coords = coords[:, 3].long()
        z_proj_sparse = z_proj_grid[batch_indices, x_coords, y_coords, z_coords]
        z_proj_st = SparseTensor(feats=z_proj_sparse, coords=coords)

        if grid_resolution_override is not None and grid_resolution_override != orig_grid_res:
            image_cond_model.grid_resolution = orig_grid_res
            image_cond_model.proj_grid = image_cond_model.proj_grid.__class__(
                grid_resolution=orig_grid_res,
                image_resolution=image_cond_model.proj_grid.image_resolution,
            ).to(device)

        if self.low_vram:
            image_cond_model.cpu()
        return {
            'cond': {'global': z_global, 'proj': z_proj_st},
            'neg_cond': {'global': torch.zeros_like(z_global), 'proj': SparseTensor(feats=torch.zeros_like(z_proj_sparse), coords=coords)},
        }
        
    # ------------------------------------------------------------------
    # Pixal3D multi-view proj conditioning
    #
    # Same cascade as the single-view Pixal3D path (SS -> Shape 512 -> Shape 1024
    # -> Tex 1024); the only difference is the image condition. Instead of one
    # image at the canonical front view it takes V views with explicit c2w
    # matrices and lets DinoV3ProjMultiViewFeatureExtractor project all of them
    # into the shared 3D grid, averaging the per-view features.
    #
    # Because the fusion is "average", the fused z_proj has exactly the
    # single-view shape [B, R^3, C], so every per-block proj_linear / proj
    # cross-attn weight of the *_mv denoisers stays compatible. View 0 is the
    # main view and its calc_mat_0 == F by construction, so V=1 degenerates to
    # the single-view path.
    #
    # `views` is the bundle built by trellis2.utils.mv_camera.build_views().
    # ------------------------------------------------------------------

    @staticmethod
    def _mv_image_for(views: dict, image_cond_model: nn.Module) -> torch.Tensor:
        """
        Pick the pre-decoded [1, V, 3, H, W] batch matching this stage input size.

        Unlike the single-view extractor (which takes PIL and resizes internally), the
        multi-view one takes tensors, so the caller has to supply the right resolution:
        the SS / shape-512 stages run at 512 and the 1024 stages at 1024.
        """
        size = int(image_cond_model.image_size)
        if size not in views['images']:
            raise KeyError(
                f"No view images at resolution {size}; got {sorted(views['images'])}. "
                f"Build them with mv_camera.build_views(image_sizes=...).")
        return views['images'][size]

    def _run_mv_extractor(self, image_cond_model: nn.Module, views: dict):
        device = self.device
        image = self._mv_image_for(views, image_cond_model).to(device)
        cam_angle = views['camera_angle_x'].to(device=device, dtype=torch.float32)
        dist = views['camera_distance'].to(device=device, dtype=torch.float32)
        transform_matrix = views['transform_matrix'].to(device=device, dtype=torch.float32)
        # mesh_scale is per-object, i.e. [B]; the extractor expands it over views.
        scale = torch.as_tensor(views['mesh_scale'], dtype=torch.float32, device=device).reshape(-1)
        return image_cond_model(
            image,
            camera_angle_x=cam_angle,
            distance=dist,
            mesh_scale=scale,
            transform_matrix=transform_matrix,
        )

    @torch.no_grad()
    def get_proj_cond_ss_mv(
        self,
        views: dict,
        image_cond_model: nn.Module = None,
    ) -> dict:
        """Multi-view proj conditioning for the sparse structure stage (dense grid)."""
        print('Getting MultiView Proj Image Cond ...')
        if image_cond_model is None:
            image_cond_model = self.load_pixal3d_mv_image_cond_ss()
        # The MV cond models are built lazily, after pipeline.to(), so they always
        # start on CPU -- move them in regardless of mode and only offload again
        # when low_vram is on.
        image_cond_model.to(self.device)
        z_global, z_proj = self._run_mv_extractor(image_cond_model, views)
        if self.low_vram:
            image_cond_model.cpu()
        return {
            'cond': {'global': z_global, 'proj': z_proj},
            'neg_cond': {'global': torch.zeros_like(z_global), 'proj': torch.zeros_like(z_proj)},
        }

    @torch.no_grad()
    def get_proj_cond_shape_mv(
        self,
        image_cond_model: nn.Module,
        views: dict,
        coords: torch.Tensor,
        grid_resolution_override: int = None,
    ) -> dict:
        """Multi-view proj conditioning for the shape / texture stages (sparse tokens)."""
        print('Getting MultiView Projected Image Cond ...')
        device = self.device
        # See get_proj_cond_ss_mv: these models are built after pipeline.to().
        image_cond_model.to(device)

        # The HR cascade grid resolution floats with the token budget (1536/16=96 and
        # down), so it can differ from what this stage was trained at; swap the grid.
        orig_grid_res = image_cond_model.grid_resolution
        override = (grid_resolution_override is not None
                    and grid_resolution_override != orig_grid_res)
        if override:
            image_cond_model.grid_resolution = grid_resolution_override
            image_cond_model.proj_grid = image_cond_model.proj_grid.__class__(
                grid_resolution=grid_resolution_override,
                image_resolution=image_cond_model.proj_grid.image_resolution,
            ).to(device)

        z_global, z_proj = self._run_mv_extractor(image_cond_model, views)

        B = z_global.shape[0]
        grid_res = image_cond_model.grid_resolution
        b_idx = coords[:, 0].long()
        x_idx = coords[:, 1].long()
        y_idx = coords[:, 2].long()
        z_idx = coords[:, 3].long()
        z_proj_grid = z_proj.reshape(B, grid_res, grid_res, grid_res, -1)
        z_proj_sparse = z_proj_grid[b_idx, x_idx, y_idx, z_idx]
        z_proj_st = SparseTensor(feats=z_proj_sparse, coords=coords)

        if override:
            image_cond_model.grid_resolution = orig_grid_res
            image_cond_model.proj_grid = image_cond_model.proj_grid.__class__(
                grid_resolution=orig_grid_res,
                image_resolution=image_cond_model.proj_grid.image_resolution,
            ).to(device)

        if self.low_vram:
            image_cond_model.cpu()
        return {
            'cond': {'global': z_global, 'proj': z_proj_st},
            'neg_cond': {
                'global': torch.zeros_like(z_global),
                'proj': SparseTensor(feats=torch.zeros_like(z_proj_sparse), coords=coords),
            },
        }


    @torch.no_grad()        
    def get_moge_camera_config(self, image):
        from ..utils.camera import get_camera_params_wild_moge
            
        camera_config = get_camera_params_wild_moge(image, self.moge_model)
        print(camera_config)

        return camera_config

    def preprocess_image(self, input: Image.Image) -> Image.Image:
        """
        Preprocess the input image.
        """
        # if has alpha channel, use it directly; otherwise, remove background
        has_alpha = False
        if input.mode == 'RGBA':
            alpha = np.array(input)[:, :, 3]
            if not np.all(alpha == 255):
                has_alpha = True
        max_size = max(input.size)
        scale = min(1, 1024 / max_size)
        if scale < 1:
            input = input.resize((int(input.width * scale), int(input.height * scale)), Image.Resampling.LANCZOS)
        if has_alpha:
            output = input
        else:
            input = input.convert('RGB')
            if self.low_vram:
                self.rembg_model.to(self.device)
            output = self.rembg_model(input)
            if self.low_vram:
                self.rembg_model.cpu()
        output_np = np.array(output)
        alpha = output_np[:, :, 3]
        bbox = np.argwhere(alpha > 0.8 * 255)
        bbox = np.min(bbox[:, 1]), np.min(bbox[:, 0]), np.max(bbox[:, 1]), np.max(bbox[:, 0])
        center = (bbox[0] + bbox[2]) / 2, (bbox[1] + bbox[3]) / 2
        size = max(bbox[2] - bbox[0], bbox[3] - bbox[1])
        size = int(size * 1)
        bbox = center[0] - size // 2, center[1] - size // 2, center[0] + size // 2, center[1] + size // 2
        output = output.crop(bbox)  # type: ignore
        output = np.array(output).astype(np.float32) / 255
        output = output[:, :, :3] * output[:, :, 3:4]
        output = Image.fromarray((output * 255).astype(np.uint8))
        return output

    @torch.no_grad()        
    def get_cond(
        self,
        image: Union[torch.Tensor, Image.Image, List[Image.Image]],
        resolution: int,
        include_neg_cond: bool = True,
        *,
        fusion_mode: str = "concat",   # "concat" or "mean"
        max_views: int = 4,            # safety cap for 3090
    ) -> dict:
        """
        Get the conditioning information for the model.

        Args:
            image: One of:
                - PIL Image
                - list[PIL Image] (multi-view)
                - torch.Tensor batch (B,H,W,C) from ComfyUI
            resolution: Conditioning resolution (e.g. 512 or 1024)
            include_neg_cond: Whether to include negative conditioning
            fusion_mode: "concat" (recommended) or "mean"
            max_views: Max number of views to fuse when list/batch is provided

        Returns:
            dict with keys: cond (+ neg_cond if include_neg_cond)
        """
        self.image_cond_model.image_size = resolution

        # ---- Normalize input into what image_cond_model expects ----
        # Most implementations expect PIL image or list[PIL images].
        if isinstance(image, torch.Tensor):
            # Expect ComfyUI IMAGE tensor: (B,H,W,C) float in [0,1]
            if image.ndim == 4:
                # Lazy import to avoid circulars if tensor2pil is in nodes/utils
                from .nodes import tensor2pil 
                images = [tensor2pil(image[i]) for i in range(min(int(image.shape[0]), max_views))]
            else:
                raise ValueError(f"Expected image tensor with shape (B,H,W,C), got {tuple(image.shape)}")
        elif isinstance(image, Image.Image):
            images = [image]
        elif isinstance(image, (list, tuple)):
            # list of PIL images
            images = list(image)[:max_views]
            if not images:
                raise ValueError("Empty image list provided to get_cond().")
            if not all(isinstance(im, Image.Image) for im in images):
                raise TypeError("get_cond() received a list/tuple but not all elements are PIL Images.")
        else:
            raise TypeError(f"Unsupported image type for get_cond(): {type(image)}")

        if self.low_vram:
            self.image_cond_model.to(self.device)

        # ---- Extract per-view conditioning ----
        cond = self.image_cond_model(images)

        # Normalize shapes:
        # Common outputs:
        #   - (V, N, D) for multi-view
        #   - (1, N, D) for single-view list length=1
        #   - (N, D) for some single-image extractors
        if cond.ndim == 2:
            # (N, D) -> (1, N, D)
            cond = cond.unsqueeze(0)
        elif cond.ndim != 3:
            raise RuntimeError(f"Unexpected cond ndim={cond.ndim}, shape={tuple(cond.shape)}")

        # If we passed multiple views, fuse them into one conditioning sequence
        if cond.shape[0] > 1:
            if fusion_mode == "concat":
                # (V, N, D) -> (1, V*N, D)
                cond = cond.reshape(1, -1, cond.shape[-1])
            elif fusion_mode == "mean":
                # (V, N, D) -> (1, N, D)
                cond = cond.mean(dim=0, keepdim=True)
            else:
                raise ValueError(f"Unknown fusion_mode: {fusion_mode}")

        if self.low_vram:
            self.image_cond_model.cpu()

        if not include_neg_cond:
            return {"cond": cond}

        neg_cond = torch.zeros_like(cond)
        return {"cond": cond, "neg_cond": neg_cond}

    @torch.no_grad()
    def sample_sparse_structure(
        self,
        cond: dict,
        resolution: int,
        num_samples: int = 1,
        sampler_params: dict = {},
        fill_holes: bool = False,
        hole_structure: int = 1,
        hole_iterations: int = 1,
        hole_fill_algorithm: str = "remove_small_holes",
        keep_only_shell: bool = False,
        verbose: bool = False,
        dino_lock: float = 0.0,
        dino_substeps: int = 2,
        dino_foundation_cap: float = 0.92
    ) -> torch.Tensor:
        """
        Sample sparse structures with the given conditioning.
        
        Args:
            cond (dict): The conditioning information.
            resolution (int): The resolution of the sparse structure.
            num_samples (int): The number of samples to generate.
            sampler_params (dict): Additional parameters for the sampler.
        """
        if self.low_vram:
            cond = self._cond_to(cond, self.device)                         
        # Sample sparse structure latent
        flow_model = self.models['sparse_structure_flow_model']
        reso = flow_model.resolution
        in_channels = flow_model.in_channels
        noise = torch.randn(num_samples, in_channels, reso, reso, reso).to(self.device)
        sampler_params = {**self.sparse_structure_sampler_params, **sampler_params}
        if self.low_vram:
            flow_model.to(self.device)
        z_s = self.sparse_structure_sampler.sample(
            flow_model,
            noise,
            **cond,
            **sampler_params,
            verbose=verbose,
            tqdm_desc="Sampling sparse structure",
            dino_lock=dino_lock,
            dino_substeps=dino_substeps,
            dino_foundation_cap=dino_foundation_cap
        ).samples
        if self.low_vram:
            flow_model.cpu()
            self._cleanup_cuda()        
        # Decode sparse structure latent
        decoder = self.models['sparse_structure_decoder']
        if self.low_vram:
            decoder.to(self.device)
        decoded = decoder(z_s) > 0
        if self.low_vram:
            decoder.cpu()
            self._cleanup_cuda()
            
        # if resolution != decoded.shape[2]:
            # ratio = decoded.shape[2] // resolution
            # decoded = torch.nn.functional.max_pool3d(decoded.float(), ratio, ratio, 0) > 0.5
        if resolution != decoded.shape[2]:
            if resolution < decoded.shape[2]:
                ratio = decoded.shape[2] // resolution
                decoded = torch.nn.functional.max_pool3d(decoded.float(), ratio, ratio, 0) > 0.5
            else:
                decoded = torch.nn.functional.interpolate(decoded.float(), size=(resolution, resolution, resolution), mode='nearest') > 0.5

        # Optionally fill holes in the sparse voxel grid using the selected algorithm
        if fill_holes:
            try:
                from scipy.ndimage import binary_closing, label, binary_fill_holes
                arr = decoded.cpu().numpy()
                if arr.ndim == 5:
                    arr = arr[:, 0]
                closed = np.zeros_like(arr)
                for b in range(arr.shape[0]):
                    filled = arr[b].astype(np.bool_)
                    inv = ~filled
                    labeled, num_features = label(inv)
                    border_mask = np.zeros_like(inv)
                    border_mask[0,:,:] = border_mask[-1,:,:] = 1
                    border_mask[:,0,:] = border_mask[:,-1,:] = 1
                    border_mask[:,:,0] = border_mask[:,:,-1] = 1
                    border_labels = np.unique(labeled[border_mask==1])
                    holes = np.isin(labeled, border_labels, invert=True) & (labeled > 0)
                    n_holes = np.unique(labeled[holes]).size
                    print(f"[Sparse HoleFill] Batch {b}: Found {n_holes} holes before filling.")
                    if hole_fill_algorithm == "morphological_closing":
                        closed[b] = binary_closing(arr[b], structure=np.ones((hole_structure,)*3), iterations=hole_iterations)
                    elif hole_fill_algorithm == "flood_fill":
                        # Robust structure-preserving hole filling:
                        # 1. Morphological closing to connect small gaps
                        # 2. Fill internal holes
                        # 3. Keep only the largest connected component
                        from scipy.ndimage import binary_closing, label, binary_fill_holes
                        # Step 1: Morphological closing (small structure, 1 iter)
                        closed1 = binary_closing(arr[b], structure=np.ones((hole_structure,)*3), iterations=hole_iterations)
                        # Step 2: Fill internal holes
                        filled = binary_fill_holes(closed1)
                        # Step 3: Keep only the largest connected component
                        labeled, num = label(filled)
                        if num > 0:
                            sizes = np.bincount(labeled.ravel())
                            sizes[0] = 0  # background
                            largest = sizes.argmax()
                            closed[b] = (labeled == largest)
                        else:
                            closed[b] = filled                     
                    elif hole_fill_algorithm == "remove_small_holes":
                        # Remove small holes by area (2D slices)
                        from skimage.morphology import remove_small_holes
                        # Apply per-slice (z axis)
                        temp = np.copy(arr[b])
                        for z in range(temp.shape[0]):
                            temp[z] = remove_small_holes(temp[z].astype(bool), area_threshold=hole_structure**2)
                        closed[b] = temp
                    else:
                        print(f"[Sparse HoleFill] Unknown algorithm: {hole_fill_algorithm}, skipping.")
                        closed[b] = arr[b]
                    # Count holes after filling
                    filled2 = closed[b].astype(np.bool_)
                    inv2 = ~filled2
                    labeled2, num_features2 = label(inv2)
                    border_labels2 = np.unique(labeled2[border_mask==1])
                    holes2 = np.isin(labeled2, border_labels2, invert=True) & (labeled2 > 0)
                    n_holes2 = np.unique(labeled2[holes2]).size
                    print(f"[Sparse HoleFill] Batch {b}: {n_holes-n_holes2} holes filled, {n_holes2} remain after filling.")

                    # Optionally remove deeply interior voxels, keeping surface and near-surface structure
                    if keep_only_shell:
                        from scipy.ndimage import binary_erosion

                        filled = closed[b].astype(np.bool_)
                        before_count = int(filled.sum())
                        struct = np.ones((3, 3, 3), dtype=bool)
                        # Erode twice: only voxels surviving 2 erosion passes are >=2 layers deep
                        # This preserves thin structures (e.g. necks with 3x3 cross-section)
                        eroded = binary_erosion(filled, structure=struct, border_value=0)
                        eroded = binary_erosion(eroded, structure=struct, border_value=0)
                        # Remove only deeply interior voxels (>=2 layers from any surface)
                        shell = filled & ~eroded
                        closed[b] = shell
                        after_count = int(shell.sum())
                        if verbose:
                            print(f"[Sparse Shell] Batch {b}: {before_count} -> {after_count} voxels (removed {before_count - after_count} deeply interior)")

                decoded = torch.from_numpy(closed).to(decoded.device)


                # Debug: print tensor info before extracting coordinates
                if verbose:
                    print(f"[Sparse HoleFill] decoded shape: {decoded.shape}, dtype: {decoded.dtype}, device: {decoded.device}")
                    print(f"[Sparse HoleFill] decoded min: {decoded.min().item()}, max: {decoded.max().item()}, unique: {torch.unique(decoded)}")
                # Safety: ensure tensor is contiguous and on CPU for argwhere
                decoded = decoded.contiguous().cpu()

            except ImportError:
                print("[Warning] scipy or skimage not installed, skipping hole filling.")
            except Exception as e:
                print(f"[Warning] Hole filling failed: {e}")

            try:
                coords = torch.argwhere(decoded)[:, [0, 1, 2, 3]].int()
            except Exception as e:
                print(f"[Sparse HoleFill] Error in torch.argwhere: {e}")
                raise

            if verbose:
                print(f"[Sparse HoleFill] coords shape: {coords.shape}, min: {coords.min(dim=0).values.tolist() if coords.numel()>0 else 'empty'}, max: {coords.max(dim=0).values.tolist() if coords.numel()>0 else 'empty'}")

            if coords.numel() == 0:
                raise RuntimeError("No voxels remain after hole filling/shell extraction. The mask is empty. Adjust your input, mask, or hole filling parameters.")
        else:
            coords = torch.argwhere(decoded)[:, [0, 2, 3, 4]].int()

        coords = coords.cpu()

        del decoded
        del z_s
        if self.low_vram:
            cond = self._cond_cpu(cond)
            self._cleanup_cuda()
        return coords

    @torch.no_grad()
    def sample_shape_slat(
        self,
        cond: dict,
        flow_model,
        coords: torch.Tensor,
        sampler_params: dict = {},
        verbose: bool = True,
        dino_lock: float = 0.0,
        dino_substeps: int = 4,
        dino_foundation_cap: float = 0.92
    ) -> SparseTensor:
        """
        Sample structured latent with the given conditioning.
        
        Args:
            cond (dict): The conditioning information.
            coords (torch.Tensor): The coordinates of the sparse structure.
            sampler_params (dict): Additional parameters for the sampler.
        """
        if self.low_vram:
            cond = self._cond_to(cond, self.device)

        coords_dev = coords.to(self.device)                         
        # Sample structured latent
        noise = SparseTensor(
            feats=torch.randn(coords.shape[0], flow_model.in_channels, device=self.device),
            coords=coords_dev,
        )
        sampler_params = {**self.shape_slat_sampler_params, **sampler_params}
        if self.low_vram:
            flow_model.to(self.device)
        slat = self.shape_slat_sampler.sample(
            flow_model,
            noise,
            **cond,
            **sampler_params,
            verbose=verbose,
            dino_lock=dino_lock,
            dino_substeps=dino_substeps,
            dino_foundation_cap=dino_foundation_cap,
            tqdm_desc="Sampling shape SLat",
        ).samples
        if self.low_vram:
            flow_model.cpu()
            self._cleanup_cuda()                                

        std = torch.tensor(self.shape_slat_normalization['std'])[None].to(slat.device)
        mean = torch.tensor(self.shape_slat_normalization['mean'])[None].to(slat.device)
        slat = slat * std + mean
        
        del coords_dev
        if self.low_vram:
            cond = self._cond_cpu(cond)
            self._cleanup_cuda()

        return slat
    
    @torch.no_grad()    
    def sample_shape_slat_cascade(
        self,
        lr_cond: dict,
        cond: dict,
        flow_model_lr,
        flow_model,
        lr_resolution: int,
        resolution: int,
        coords: torch.Tensor,
        sampler_params: dict = {},
        max_num_tokens: int = 49152,
        sparse_structure_resolution: int = 32,
        verbose: bool = False,
        dino_lock: float = 0.0,
        dino_substeps: int = 4,
        dino_foundation_cap: float = 0.92
    ) -> SparseTensor:
        """
        Sample structured latent with the given conditioning.
        
        Args:
            cond (dict): The conditioning information.
            coords (torch.Tensor): The coordinates of the sparse structure.
            sampler_params (dict): Additional parameters for the sampler.
        """
        # LR

        if self.low_vram:
            lr_cond = self._cond_to(lr_cond, self.device)
            cond = self._cond_to(cond, self.device)

        coords_dev = coords.to(self.device)                         
        # Sample structured latent
        noise = SparseTensor(
            feats=torch.randn(coords.shape[0], flow_model.in_channels, device=self.device),
            coords=coords_dev,
        )
        sampler_params = {**self.shape_slat_sampler_params, **sampler_params}
        if self.low_vram:
            flow_model_lr.to(self.device)
        slat = self.shape_slat_sampler.sample(
            flow_model_lr,
            noise,
            **lr_cond,
            **sampler_params,
            verbose=verbose,
            dino_lock=dino_lock,
            dino_substeps=dino_substeps,
            dino_foundation_cap=dino_foundation_cap,
            tqdm_desc="Sampling shape SLat (LR)",
        ).samples
        if self.low_vram:
            flow_model_lr.cpu()
            self._cleanup_cuda()                                
        std = torch.tensor(self.shape_slat_normalization['std'])[None].to(slat.device)
        mean = torch.tensor(self.shape_slat_normalization['mean'])[None].to(slat.device)
        slat = slat * std + mean
        
        del coords_dev
        if self.low_vram:
            lr_cond = self._cond_cpu(lr_cond)
            self._cleanup_cuda()

        # Upsample       
        self.load_shape_slat_decoder()
        if self.low_vram:
            self.models['shape_slat_decoder'].to(self.device)
            self.models['shape_slat_decoder'].low_vram = True
        hr_coords = self.models['shape_slat_decoder'].upsample(slat, upsample_times=4)
        if self.low_vram:
            self.models['shape_slat_decoder'].cpu()
            self.models['shape_slat_decoder'].low_vram = False
        hr_resolution = resolution
        
        if not self.keep_models_loaded:
            self.unload_shape_slat_decoder()
            
        ratio = (sparse_structure_resolution / 32)
        
        while True:
            quant_coords = torch.cat([
                hr_coords[:, :1],
                ((hr_coords[:, 1:] + 0.5) / (lr_resolution * ratio) * (hr_resolution // 16)).int(),
            ], dim=1)
            coords = quant_coords.unique(dim=0)
            num_tokens = coords.shape[0]
            if num_tokens < max_num_tokens:
                if hr_resolution != resolution:
                    print(f"Due to the limited number of tokens, the resolution is reduced to {hr_resolution}.")
                print(f"Num Tokens: {num_tokens}")
                break
            hr_resolution -= 128
            if hr_resolution < 1024 and resolution >= 1024:
                print(f"Num Tokens: {num_tokens}")
                hr_resolution = 1024
                break
            if hr_resolution < 512:
                print(f"Num Tokens: {num_tokens}")
                hr_resolution = 512
                break
        
        coords_dev = coords.to(self.device)                                           
        # Sample structured latent
        noise = SparseTensor(
            feats=torch.randn(coords.shape[0], flow_model.in_channels, device=self.device),
            coords=coords_dev,
        )
        sampler_params = {**self.shape_slat_sampler_params, **sampler_params}
        if self.low_vram:
            flow_model.to(self.device)
        slat = self.shape_slat_sampler.sample(
            flow_model,
            noise,
            **cond,
            **sampler_params,
            verbose=verbose,
            dino_lock=dino_lock,
            dino_substeps=dino_substeps,
            dino_foundation_cap=dino_foundation_cap,
            tqdm_desc="Sampling shape SLat (HR)",
        ).samples
        if self.low_vram:
            flow_model.cpu()
            self._cleanup_cuda()                                

        std = torch.tensor(self.shape_slat_normalization['std'])[None].to(slat.device)
        mean = torch.tensor(self.shape_slat_normalization['mean'])[None].to(slat.device)
        slat = slat * std + mean
        
        del coords_dev
        if self.low_vram:
            cond = self._cond_cpu(cond)
            self._cleanup_cuda()

        return slat, hr_resolution

    @torch.no_grad()
    def decode_shape_slat(
        self,
        slat: SparseTensor,
        resolution: int,
        use_tiled: bool = True,
    ) -> Tuple[List[Mesh], List[SparseTensor]]:
        """
        Decode the structured latent.

        Args:
            slat (SparseTensor): The structured latent.

        Returns:
            List[Mesh]: The decoded meshes.
            List[SparseTensor]: The decoded substructures.
        """
        
        self.load_shape_slat_decoder()
        
        self.models['shape_slat_decoder'].set_resolution(resolution)
        if self.low_vram:
            self.models['shape_slat_decoder'].to(self.device)
            self.models['shape_slat_decoder'].low_vram = True
        ret = self.models['shape_slat_decoder'](slat, return_subs=True, useTiled=use_tiled)
        if self.low_vram:
            self.models['shape_slat_decoder'].cpu()
            self.models['shape_slat_decoder'].low_vram = False
            self._cleanup_cuda()                
        
        if not self.keep_models_loaded:        
            self.unload_shape_slat_decoder()
            
        return ret
    
    @torch.no_grad()    
    def sample_tex_slat(
        self,
        cond: dict,
        flow_model,
        shape_slat: SparseTensor,
        sampler_params: dict = {},
        verbose: bool = False,
        dino_lock: float = 0.0,
        dino_substeps: int = 4,
        dino_foundation_cap: float = 0.92
    ) -> SparseTensor:
        """
        Sample structured latent with the given conditioning.
        
        Args:
            cond (dict): The conditioning information.
            shape_slat (SparseTensor): The structured latent for shape
            sampler_params (dict): Additional parameters for the sampler.
        """
        if self.low_vram:
            cond = self._cond_to(cond, self.device)                                                   
        # Sample structured latent
        std = torch.tensor(self.shape_slat_normalization['std'])[None].to(shape_slat.device)
        mean = torch.tensor(self.shape_slat_normalization['mean'])[None].to(shape_slat.device)
        shape_slat = (shape_slat - mean) / std

        in_channels = flow_model.in_channels if isinstance(flow_model, nn.Module) else flow_model[0].in_channels
        noise = shape_slat.replace(feats=torch.randn(shape_slat.coords.shape[0], in_channels - shape_slat.feats.shape[1]).to(self.device))
        sampler_params = {**self.tex_slat_sampler_params, **sampler_params}
        if self.low_vram:
            flow_model.to(self.device)
        slat = self.tex_slat_sampler.sample(
            flow_model,
            noise,
            concat_cond=shape_slat,
            **cond,
            **sampler_params,
            verbose=verbose,
            dino_lock=dino_lock,
            dino_substeps=dino_substeps,
            dino_foundation_cap=dino_foundation_cap,
            tqdm_desc="Sampling texture SLat",
        ).samples
        if self.low_vram:
            flow_model.cpu()
            self._cleanup_cuda()                    

        std = torch.tensor(self.tex_slat_normalization['std'])[None].to(slat.device)
        mean = torch.tensor(self.tex_slat_normalization['mean'])[None].to(slat.device)
        slat = slat * std + mean
        
        if self.low_vram:
            cond = self._cond_cpu(cond)
            self._cleanup_cuda()                         
        return slat

    def decode_tex_slat(
        self,
        slat: SparseTensor,
        subs: List[SparseTensor] = None,
    ) -> SparseTensor:
        """
        Decode the structured latent.

        Args:
            slat (SparseTensor): The structured latent.

        Returns:
            SparseTensor: The decoded texture voxels
        """
        
        self.load_tex_slat_decoder()
        
        if self.low_vram:
            self.models['tex_slat_decoder'].to(self.device)
            self.models['tex_slat_decoder'].low_vram = True                                               
            
        if subs is None:
            ret = self.models['tex_slat_decoder'](slat) * 0.5 + 0.5
        else:
            slat.clear_spatial_cache()
            ret = self.models['tex_slat_decoder'](slat, guide_subs=subs) * 0.5 + 0.5
            
        if self.low_vram:
            self.models['tex_slat_decoder'].cpu()
            self.models['tex_slat_decoder'].low_vram = False
            self._cleanup_cuda()
        
        if not self.keep_models_loaded:
            self.unload_tex_slat_decoder()
        
        return ret
    
    @torch.no_grad()
    def decode_latent(
        self,
        shape_slat: SparseTensor,
        tex_slat: SparseTensor,
        resolution: int,
        use_tiled: bool = True,
    ) -> List[MeshWithVoxel]:
        """
        Decode the latent codes.

        Args:
            shape_slat (SparseTensor): The structured latent for shape.
            tex_slat (SparseTensor): The structured latent for texture.
            resolution (int): The resolution of the output.
        """
        meshes, subs = self.decode_shape_slat(shape_slat, resolution, use_tiled=use_tiled)
        if self.low_vram:
            self._cleanup_cuda()                                                         
            
        if tex_slat is None:
            if self.low_vram:
                self._cleanup_cuda()                                                         
            out_mesh = []
            for m in meshes:
                m.fill_holes()
                out_mesh.append(
                    MeshWithVoxel(
                        m.vertices, m.faces,
                        origin = [-0.5, -0.5, -0.5],
                        voxel_size = 1 / resolution,
                        coords = None,
                        attrs = None,
                        voxel_shape = None,
                        layout=self.pbr_attr_layout
                    )
                )
            return out_mesh
        
        else:    
            tex_voxels = self.decode_tex_slat(tex_slat, subs)
            if self.low_vram:
                self._cleanup_cuda()                                                         
            out_mesh = []
            for m, v in zip(meshes, tex_voxels):
                m.fill_holes()
                out_mesh.append(
                    MeshWithVoxel(
                        m.vertices, m.faces,
                        origin = [-0.5, -0.5, -0.5],
                        voxel_size = 1 / resolution,
                        coords = v.coords[:, 1:],
                        attrs = v.feats,
                        voxel_shape = torch.Size([*v.shape, *v.spatial_shape]),
                        layout=self.pbr_attr_layout
                    )
                )
            return out_mesh
    
    @torch.inference_mode()
    def run(
        self,
        image: Image.Image,
        num_samples: int = 1,
        seed: int = 42,
        sparse_structure_sampler_params: dict = {},
        shape_slat_sampler_params: dict = {},
        tex_slat_sampler_params: dict = {},
        preprocess_image: bool = False,
        return_latent: bool = False,
        pipeline_type: Optional[str] = None,
        max_num_tokens: int = 49152,
        sparse_structure_resolution: int = 32,
        max_views: int = 4,
        generate_texture_slat = True,
        use_tiled: bool = True,
        pbar = None,
        sampler: str = "euler",
        verbose: bool = False,
        fill_holes: bool = True,
        hole_iterations: int = 1,
        dino_lock: float = 0.00,
        dino_substeps: int = 4,
        hole_fill_algorithm = "remove_small_holes",
        dino_foundation_cap: float = 0.92,
        keep_only_shell: bool = True,
    ) -> List[MeshWithVoxel]:
        """
        Run the pipeline.

        Args:
            image (Image.Image): The image prompt.
            num_samples (int): The number of samples to generate.
            seed (int): The random seed.
            sparse_structure_sampler_params (dict): Additional parameters for the sparse structure sampler.
            shape_slat_sampler_params (dict): Additional parameters for the shape SLat sampler.
            tex_slat_sampler_params (dict): Additional parameters for the texture SLat sampler.
            preprocess_image (bool): Whether to preprocess the image.
            return_latent (bool): Whether to return the latent codes.
            pipeline_type (str): The type of the pipeline. Options: '512', '1024', '1024_cascade', '1536_cascade'.
            max_num_tokens (int): The maximum number of tokens to use.
        """
        self.switch_samplers(sampler)
        
        # Check pipeline type
        pipeline_type = pipeline_type or self.default_pipeline_type
        # if pipeline_type == '512':
            # assert 'shape_slat_flow_model_512' in self.models, "No 512 resolution shape SLat flow model found."
            # assert 'tex_slat_flow_model_512' in self.models, "No 512 resolution texture SLat flow model found."
        # elif pipeline_type == '1024':
            # assert 'shape_slat_flow_model_1024' in self.models, "No 1024 resolution shape SLat flow model found."
            # assert 'tex_slat_flow_model_1024' in self.models, "No 1024 resolution texture SLat flow model found."
        # elif pipeline_type == '1024_cascade':
            # assert 'shape_slat_flow_model_512' in self.models, "No 512 resolution shape SLat flow model found."
            # assert 'shape_slat_flow_model_1024' in self.models, "No 1024 resolution shape SLat flow model found."
            # assert 'tex_slat_flow_model_1024' in self.models, "No 1024 resolution texture SLat flow model found."
        # elif pipeline_type == '1536_cascade':
            # assert 'shape_slat_flow_model_512' in self.models, "No 512 resolution shape SLat flow model found."
            # assert 'shape_slat_flow_model_1024' in self.models, "No 1024 resolution shape SLat flow model found."
            # assert 'tex_slat_flow_model_1024' in self.models, "No 1024 resolution texture SLat flow model found."
        # else:
            # raise ValueError(f"Invalid pipeline type: {pipeline_type}")
        
        # Accept either a single PIL image or a list of PIL images (multi-view)
        if isinstance(image, (list, tuple)):
            images = list(image)
        else:
            images = [image]

        if preprocess_image:
            images = [self.preprocess_image(im) for im in images]
            
        seed_all(seed)
        
        # Get Image Cond
        self.load_image_cond_model()        
        # Multi-view conditioning happens inside get_cond()        
        cond_512  = self.get_cond(images, 512, max_views = max_views)        
        cond_1024 = self.get_cond(images, 1024, max_views = max_views) if pipeline_type != '512' else None
        
        if pbar is not None:
            pbar.update(1)
        
        if not self.keep_models_loaded:
            self.unload_image_cond_model()
        
        #ss_res = {'512': 32, '1024': 64, '1024_cascade': 32, '1536_cascade': 32}[pipeline_type]
        
        # Sampling Sparse Structure
        self.load_sparse_structure_model()        
        coords = self.sample_sparse_structure(
            cond_512, sparse_structure_resolution,
            num_samples, sparse_structure_sampler_params,
            verbose = verbose,
            fill_holes = fill_holes,
            hole_iterations = hole_iterations,
            dino_lock = dino_lock,
            dino_substeps = dino_substeps,
            hole_fill_algorithm=hole_fill_algorithm,
            dino_foundation_cap=dino_foundation_cap,
            keep_only_shell=keep_only_shell
        )
        
        if pbar is not None:
            pbar.update(1)
        
        if not self.keep_models_loaded:
            self.unload_sparse_structure_model()
        
        # Sampling Shape
        if pipeline_type == '512':            
            self.unload_shape_slat_flow_model_1024()
            self.load_shape_slat_flow_model_512()            
            shape_slat = self.sample_shape_slat(
                cond_512, self.models['shape_slat_flow_model_512'],
                coords, shape_slat_sampler_params,
                verbose = verbose,
                dino_lock = dino_lock,
                dino_substeps = dino_substeps,
                dino_foundation_cap = dino_foundation_cap
            )
            
            if pbar is not None:
                pbar.update(1)
            
            if not self.keep_models_loaded:
                self.unload_shape_slat_flow_model_512()
            
            if generate_texture_slat:
                self.unload_tex_slat_flow_model_1024()
                self.load_tex_slat_flow_model_512()
                tex_slat = self.sample_tex_slat(
                    cond_512, self.models['tex_slat_flow_model_512'],
                    shape_slat, tex_slat_sampler_params,
                    verbose = verbose,
                    dino_lock = dino_lock,
                    dino_substeps = dino_substeps,
                    dino_foundation_cap = dino_foundation_cap
                )
                
                if pbar is not None:
                    pbar.update(1)
            
            if not self.keep_models_loaded:
                self.unload_tex_slat_flow_model_512()
            
            res = 512
        elif pipeline_type == '1024':
            self.unload_shape_slat_flow_model_512()
            self.load_shape_slat_flow_model_1024()
            shape_slat = self.sample_shape_slat(
                cond_1024, self.models['shape_slat_flow_model_1024'],
                coords, shape_slat_sampler_params,
                verbose = verbose,
                dino_lock = dino_lock,
                dino_substeps = dino_substeps,
                dino_foundation_cap = dino_foundation_cap
            )
            
            if pbar is not None:
                pbar.update(1)
            
            if not self.keep_models_loaded:
                self.unload_shape_slat_flow_model_1024()
            
            if generate_texture_slat:
                self.unload_tex_slat_flow_model_512()
                self.load_tex_slat_flow_model_1024()
                tex_slat = self.sample_tex_slat(
                    cond_1024, self.models['tex_slat_flow_model_1024'],
                    shape_slat, tex_slat_sampler_params,
                    verbose = verbose,
                    dino_lock = dino_lock,
                    dino_substeps = dino_substeps,
                    dino_foundation_cap = dino_foundation_cap
                )
                
                if pbar is not None:
                    pbar.update(1)
            
            if not self.keep_models_loaded:
                self.unload_tex_slat_flow_model_1024()
                
            res = 1024
        elif pipeline_type == '1024_cascade':
            self.load_shape_slat_flow_model_512()
            self.load_shape_slat_flow_model_1024()            
            shape_slat, res = self.sample_shape_slat_cascade(
                cond_512, cond_1024,
                self.models['shape_slat_flow_model_512'], self.models['shape_slat_flow_model_1024'],
                512, 1024,
                coords, shape_slat_sampler_params,
                max_num_tokens,
                sparse_structure_resolution,
                verbose = verbose,
                dino_lock = dino_lock,
                dino_substeps = dino_substeps,
                dino_foundation_cap = dino_foundation_cap
            )
            
            if pbar is not None:
                pbar.update(1)
            
            if not self.keep_models_loaded:
                self.unload_shape_slat_flow_model_512()
                self.unload_shape_slat_flow_model_1024()
            
            if generate_texture_slat:
                self.unload_tex_slat_flow_model_512()
                self.load_tex_slat_flow_model_1024()
                tex_slat = self.sample_tex_slat(
                    cond_1024, self.models['tex_slat_flow_model_1024'],
                    shape_slat, tex_slat_sampler_params,
                    verbose = verbose,
                    dino_lock = dino_lock,
                    dino_substeps = dino_substeps,
                    dino_foundation_cap = dino_foundation_cap
                )
                
            if pbar is not None:
                pbar.update(1)
            
            if not self.keep_models_loaded:
                self.unload_tex_slat_flow_model_1024()
        elif pipeline_type == '2048_cascade':
            self.load_shape_slat_flow_model_512()
            self.load_shape_slat_flow_model_1024()
            shape_slat, res = self.sample_shape_slat_cascade(
                cond_512, cond_1024,
                self.models['shape_slat_flow_model_512'], self.models['shape_slat_flow_model_1024'],
                512, 2048,
                coords, shape_slat_sampler_params,
                max_num_tokens,
                sparse_structure_resolution,
                verbose = verbose,
                dino_lock = dino_lock,
                dino_substeps = dino_substeps,
                dino_foundation_cap = dino_foundation_cap
            )
            
            if pbar is not None:
                pbar.update(1)
            
            if not self.keep_models_loaded:
                self.unload_shape_slat_flow_model_512()
                self.unload_shape_slat_flow_model_1024()
                
            if generate_texture_slat:
                self.unload_tex_slat_flow_model_512()
                self.load_tex_slat_flow_model_1024()
                tex_slat = self.sample_tex_slat(
                    cond_1024, self.models['tex_slat_flow_model_1024'],
                    shape_slat, tex_slat_sampler_params,
                    verbose = verbose,
                    dino_lock = dino_lock,
                    dino_substeps = dino_substeps,
                    dino_foundation_cap = dino_foundation_cap
                )
                
                if pbar is not None:
                    pbar.update(1)
                
            if not self.keep_models_loaded:
                self.unload_tex_slat_flow_model_1024()
        elif pipeline_type == '4096_cascade':
            self.load_shape_slat_flow_model_512()
            self.load_shape_slat_flow_model_1024()
            shape_slat, res = self.sample_shape_slat_cascade(
                cond_512, cond_1024,
                self.models['shape_slat_flow_model_512'], self.models['shape_slat_flow_model_1024'],
                512, 4096,
                coords, shape_slat_sampler_params,
                max_num_tokens,
                sparse_structure_resolution,
                verbose = verbose,
                dino_lock = dino_lock,
                dino_substeps = dino_substeps,
                dino_foundation_cap = dino_foundation_cap
            )
            
            if pbar is not None:
                pbar.update(1)
            
            if not self.keep_models_loaded:
                self.unload_shape_slat_flow_model_512()
                self.unload_shape_slat_flow_model_1024()
                
            if generate_texture_slat:
                self.unload_tex_slat_flow_model_512()
                self.load_tex_slat_flow_model_1024()
                tex_slat = self.sample_tex_slat(
                    cond_1024, self.models['tex_slat_flow_model_1024'],
                    shape_slat, tex_slat_sampler_params,
                    verbose = verbose,
                    dino_lock = dino_lock,
                    dino_substeps = dino_substeps,
                    dino_foundation_cap = dino_foundation_cap
                )
                        
                if pbar is not None:
                    pbar.update(1)  
                
            if not self.keep_models_loaded:
                self.unload_tex_slat_flow_model_1024()
        elif pipeline_type == '1536_cascade':
            self.load_shape_slat_flow_model_512()
            self.load_shape_slat_flow_model_1024()                
            shape_slat, res = self.sample_shape_slat_cascade(
                cond_512, cond_1024,
                self.models['shape_slat_flow_model_512'], self.models['shape_slat_flow_model_1024'],
                512, 1536,
                coords, shape_slat_sampler_params,
                max_num_tokens,
                sparse_structure_resolution,
                verbose = verbose,
                dino_lock = dino_lock,
                dino_substeps = dino_substeps,
                dino_foundation_cap = dino_foundation_cap
            )
            
            if pbar is not None:
                pbar.update(1)
            
            if not self.keep_models_loaded:
                self.unload_shape_slat_flow_model_512()
                self.unload_shape_slat_flow_model_1024()
            
            if generate_texture_slat:            
                self.unload_tex_slat_flow_model_512()
                self.load_tex_slat_flow_model_1024()
                tex_slat = self.sample_tex_slat(
                    cond_1024, self.models['tex_slat_flow_model_1024'],
                    shape_slat, tex_slat_sampler_params,
                    verbose = verbose,
                    dino_lock = dino_lock,
                    dino_substeps = dino_substeps,
                    dino_foundation_cap = dino_foundation_cap
                )
                
                if pbar is not None:
                    pbar.update(1)
            
            if not self.keep_models_loaded:
                self.unload_tex_slat_flow_model_1024()               
            
        torch.cuda.empty_cache()
        if generate_texture_slat:
            out_mesh = self.decode_latent(shape_slat, tex_slat, res, use_tiled=use_tiled)
        else:
            out_mesh = self.decode_latent(shape_slat, None, res, use_tiled=use_tiled)
        torch.cuda.empty_cache()
        pbar.update(1)              
        if return_latent:
            if generate_texture_slat:
                return out_mesh, (shape_slat, tex_slat, res)
            else:
                return out_mesh, (shape_slat, None, res)
        else:
            return out_mesh
            
    def GetSamplerName(self, sampler):
        if sampler == 'euler':
            return 'Euler'
        elif sampler == 'rk4':
            return 'RK4'
        elif sampler == 'rk5':
            return 'RK5'
        elif sampler == 'heun':
            return 'Heun'
        else:
            return 'Euler'       
            
    @torch.no_grad()            
    def sample_shape_slat_cascade_advanced(
        self,
        lr_cond: dict,
        cond: dict,
        flow_model_lr,
        flow_model,
        lr_resolution: int,
        resolution: int,
        coords: torch.Tensor,
        low_res_sampler_params: dict = {},
        high_res_sampler_params: dict = {},
        max_num_tokens: int = 999999,
        sparse_structure_resolution: int = 32,
        low_res_sampler_name: str = 'euler',
        high_res_sampler_name: str = 'euler',
        verbose: bool = False,
        dino_lock: float = 0.0,
        dino_substeps: int = 4,
        dino_foundation_cap: float = 0.92
    ) -> SparseTensor:
        """
        Sample structured latent with the given conditioning.
        
        Args:
            cond (dict): The conditioning information.
            coords (torch.Tensor): The coordinates of the sparse structure.
            sampler_params (dict): Additional parameters for the sampler.
        """
        # LR

        if self.low_vram:
            lr_cond = self._cond_to(lr_cond, self.device)
            cond = self._cond_to(cond, self.device)

        coords_dev = coords.to(self.device)                         
        # Sample structured latent
        noise = SparseTensor(
            feats=torch.randn(coords.shape[0], flow_model.in_channels, device=self.device),
            coords=coords_dev,
        )
        sampler_params = {**self.shape_slat_sampler_params, **low_res_sampler_params}
        if self.low_vram:
            flow_model_lr.to(self.device)            
        
        args = self._pretrained_args
        sparse_sampler_prefix = self.GetSamplerName(low_res_sampler_name)
        self.shape_slat_sampler = getattr(samplers, f"Flow{sparse_sampler_prefix}GuidanceIntervalSampler")(**args['shape_slat_sampler']['args'])
            
        slat = self.shape_slat_sampler.sample(
            flow_model_lr,
            noise,
            **lr_cond,
            **sampler_params,
            verbose=verbose,
            dino_lock=dino_lock,
            dino_substeps=dino_substeps,
            dino_foundation_cap=dino_foundation_cap,
            tqdm_desc="Sampling shape SLat (LR)",
        ).samples
        if self.low_vram:
            flow_model_lr.cpu()
            self._cleanup_cuda()                                
        std = torch.tensor(self.shape_slat_normalization['std'])[None].to(slat.device)
        mean = torch.tensor(self.shape_slat_normalization['mean'])[None].to(slat.device)
        slat = slat * std + mean
        
        del coords_dev
        if self.low_vram:
            lr_cond = self._cond_cpu(lr_cond)
            self._cleanup_cuda()

        # Upsample       
        self.load_shape_slat_decoder()
        if self.low_vram:
            self.models['shape_slat_decoder'].to(self.device)
            self.models['shape_slat_decoder'].low_vram = True
        hr_coords = self.models['shape_slat_decoder'].upsample(slat, upsample_times=4)
        if self.low_vram:
            self.models['shape_slat_decoder'].cpu()
            self.models['shape_slat_decoder'].low_vram = False
        hr_resolution = resolution
        
        if not self.keep_models_loaded:
            self.unload_shape_slat_decoder()
            
        ratio = (sparse_structure_resolution / 32)
        
        while True:
            quant_coords = torch.cat([
                hr_coords[:, :1],
                ((hr_coords[:, 1:] + 0.5) / (lr_resolution * ratio) * (hr_resolution // 16)).int(),
            ], dim=1)
            coords = quant_coords.unique(dim=0)
            num_tokens = coords.shape[0]
            if num_tokens < max_num_tokens:
                if hr_resolution != resolution:
                    print(f"Due to the limited number of tokens, the resolution is reduced to {hr_resolution}.")
                print(f"Num Tokens: {num_tokens}")
                break
            hr_resolution -= 128
            if hr_resolution < 1024 and resolution >= 1024:
                print(f"Num Tokens: {num_tokens}")
                hr_resolution = 1024
                break
            if hr_resolution < 512:
                print(f"Num Tokens: {num_tokens}")
                hr_resolution = 512
                break
        
        coords_dev = coords.to(self.device)                                           
        # Sample structured latent
        noise = SparseTensor(
            feats=torch.randn(coords.shape[0], flow_model.in_channels, device=self.device),
            coords=coords_dev,
        )        
        
        sampler_params = {**self.shape_slat_sampler_params, **high_res_sampler_params}
        
        sparse_sampler_prefix = self.GetSamplerName(high_res_sampler_name)
        self.shape_slat_sampler = getattr(samplers, f"Flow{sparse_sampler_prefix}GuidanceIntervalSampler")(**args['shape_slat_sampler']['args'])        
        
        if self.low_vram:
            flow_model.to(self.device)
        slat = self.shape_slat_sampler.sample(
            flow_model,
            noise,
            **cond,
            **sampler_params,
            verbose=verbose,
            dino_lock=dino_lock,
            dino_substeps=dino_substeps,
            dino_foundation_cap=dino_foundation_cap,
            tqdm_desc="Sampling shape SLat (HR)",
        ).samples
        if self.low_vram:
            flow_model.cpu()
            self._cleanup_cuda()                                

        std = torch.tensor(self.shape_slat_normalization['std'])[None].to(slat.device)
        mean = torch.tensor(self.shape_slat_normalization['mean'])[None].to(slat.device)
        slat = slat * std + mean
        
        del coords_dev
        if self.low_vram:
            cond = self._cond_cpu(cond)
            self._cleanup_cuda()

        return slat, hr_resolution   

    @torch.no_grad()
    def sample_tex_slat_advanced(
        self,
        cond: dict,
        flow_model,
        shape_slat: SparseTensor,
        sampler_params: dict = {},
        sampler_name: str = 'euler',
        verbose: bool = False,
        dino_lock: float = 0.0,
        dino_substeps: int = 4,
        dino_foundation_cap: float = 0.92
    ) -> SparseTensor:
        """
        Sample structured latent with the given conditioning.
        
        Args:
            cond (dict): The conditioning information.
            shape_slat (SparseTensor): The structured latent for shape
            sampler_params (dict): Additional parameters for the sampler.
        """
        if self.low_vram:
            cond = self._cond_to(cond, self.device)                                                   
        # Sample structured latent
        std = torch.tensor(self.shape_slat_normalization['std'])[None].to(shape_slat.device)
        mean = torch.tensor(self.shape_slat_normalization['mean'])[None].to(shape_slat.device)
        shape_slat = (shape_slat - mean) / std

        in_channels = flow_model.in_channels if isinstance(flow_model, nn.Module) else flow_model[0].in_channels
        noise = shape_slat.replace(feats=torch.randn(shape_slat.coords.shape[0], in_channels - shape_slat.feats.shape[1]).to(self.device))
        sampler_params = {**self.tex_slat_sampler_params, **sampler_params}
        
        args = self._pretrained_args
        sparse_sampler_prefix = self.GetSamplerName(sampler_name)
        self.tex_slat_sampler = getattr(samplers, f"Flow{sparse_sampler_prefix}GuidanceIntervalSampler")(**args['tex_slat_sampler']['args'])        
        
        if self.low_vram:
            flow_model.to(self.device)
        slat = self.tex_slat_sampler.sample(
            flow_model,
            noise,
            concat_cond=shape_slat,
            **cond,
            **sampler_params,
            verbose=verbose,
            dino_lock=dino_lock,
            dino_substeps=dino_substeps,
            dino_foundation_cap=dino_foundation_cap,
            tqdm_desc="Sampling texture SLat",
        ).samples
        if self.low_vram:
            flow_model.cpu()
            self._cleanup_cuda()                    

        std = torch.tensor(self.tex_slat_normalization['std'])[None].to(slat.device)
        mean = torch.tensor(self.tex_slat_normalization['mean'])[None].to(slat.device)
        slat = slat * std + mean
        
        if self.low_vram:
            cond = self._cond_cpu(cond)
            self._cleanup_cuda()                         
        return slat        
            
    @torch.no_grad()
    def run_cascade(
        self,
        image: Image.Image,
        num_samples: int = 1,
        seed: int = 42,
        sparse_structure_sampler_params: dict = {},
        low_res_shape_slat_sampler_params: dict = {},
        high_res_shape_slat_sampler_params: dict = {},
        tex_slat_sampler_params: dict = {},
        pipeline_type: str = '1024_cascade',
        max_num_tokens: int = 999999,
        sparse_structure_resolution: int = 32,
        generate_texture_slat = True,
        use_tiled: bool = True,
        pbar = None,
        sparse_structure_sampler = 'euler',
        low_res_shape_sampler = 'euler',
        high_res_shape_sampler = 'euler',
        tex_sampler = 'euler',
        max_views: int = 4,
        verbose: bool = False,
        fill_holes: bool = True,
        hole_iterations: int = 1,
        dino_lock: float = 0.00,
        dino_substeps: int = 4,
        hole_fill_algorithm = 'remove_small_holes',
        dino_foundation_cap: float = 0.92,
        keep_only_shell: bool = True,
    ) -> List[MeshWithVoxel]:
        
        if isinstance(image, (list, tuple)):
            images = list(image)
        else:
            images = [image]
            
        seed_all(seed)
        
        # Get Image Cond
        self.load_image_cond_model()        
        # Multi-view conditioning happens inside get_cond()              
        cond_512  = self.get_cond(images, 512, max_views = max_views)        
        cond_1024 = self.get_cond(images, 1024, max_views = max_views) if pipeline_type != '512' else None
        
        if pbar is not None:
            pbar.update(1)
        
        if not self.keep_models_loaded:
            self.unload_image_cond_model()       
        
        args = self._pretrained_args
        
        #
        #self.shape_slat_sampler = getattr(samplers, f"Flow{self._sampler_prefix}GuidanceIntervalSampler")(**args['shape_slat_sampler']['args'])
        #self.tex_slat_sampler = getattr(samplers, f"Flow{self._sampler_prefix}GuidanceIntervalSampler")(**args['tex_slat_sampler']['args'])        
        
        # Sampling Sparse Structure
        sparse_sampler_prefix = self.GetSamplerName(sparse_structure_sampler)
        self.sparse_structure_sampler = getattr(samplers, f"Flow{sparse_sampler_prefix}GuidanceIntervalSampler")(**args['sparse_structure_sampler']['args'])
        self.load_sparse_structure_model()        
        coords = self.sample_sparse_structure(
            cond_512, sparse_structure_resolution,
            num_samples, sparse_structure_sampler_params,
            verbose = verbose,
            fill_holes = fill_holes,
            hole_iterations = hole_iterations,
            dino_lock = dino_lock,
            dino_substeps = dino_substeps,
            hole_fill_algorithm = hole_fill_algorithm,
            dino_foundation_cap=dino_foundation_cap,
            keep_only_shell=keep_only_shell
        )
        
        if pbar is not None:
            pbar.update(1)
        
        if not self.keep_models_loaded:
            self.unload_sparse_structure_model()
        
        # Sampling Shape
        if pipeline_type == '1024_cascade':
            self.load_shape_slat_flow_model_512()
            self.load_shape_slat_flow_model_1024()            
            shape_slat, res = self.sample_shape_slat_cascade_advanced(
                cond_512, cond_1024,
                self.models['shape_slat_flow_model_512'], self.models['shape_slat_flow_model_1024'],
                512, 1024,
                coords, low_res_shape_slat_sampler_params, high_res_shape_slat_sampler_params,
                max_num_tokens,
                sparse_structure_resolution,
                low_res_shape_sampler, high_res_shape_sampler,
                verbose = verbose,
                dino_lock = dino_lock,
                dino_substeps = dino_substeps,
                dino_foundation_cap=dino_foundation_cap
            )
            
            if pbar is not None:
                pbar.update(1)
            
            if not self.keep_models_loaded:
                self.unload_shape_slat_flow_model_512()
                self.unload_shape_slat_flow_model_1024()
            
            if generate_texture_slat:
                self.unload_tex_slat_flow_model_512()
                self.load_tex_slat_flow_model_1024()
                tex_slat = self.sample_tex_slat_advanced(
                    cond_1024, self.models['tex_slat_flow_model_1024'],
                    shape_slat, tex_slat_sampler_params, tex_sampler,
                    verbose = verbose,
                    dino_lock = dino_lock,
                    dino_substeps = dino_substeps,
                    dino_foundation_cap=dino_foundation_cap
                )
                
            if pbar is not None:
                pbar.update(1)
            
            if not self.keep_models_loaded:
                self.unload_tex_slat_flow_model_1024()
        elif pipeline_type == '1536_cascade':
            self.load_shape_slat_flow_model_512()
            self.load_shape_slat_flow_model_1024()            
            shape_slat, res = self.sample_shape_slat_cascade_advanced(
                cond_512, cond_1024,
                self.models['shape_slat_flow_model_512'], self.models['shape_slat_flow_model_1024'],
                512, 1536,
                coords, low_res_shape_slat_sampler_params, high_res_shape_slat_sampler_params,
                max_num_tokens,
                sparse_structure_resolution,
                low_res_shape_sampler, high_res_shape_sampler,
                verbose = verbose,
                dino_lock = dino_lock,
                dino_substeps = dino_substeps,
                dino_foundation_cap=dino_foundation_cap
            )
            
            if pbar is not None:
                pbar.update(1)
            
            if not self.keep_models_loaded:
                self.unload_shape_slat_flow_model_512()
                self.unload_shape_slat_flow_model_1024()
            
            if generate_texture_slat:
                self.unload_tex_slat_flow_model_512()
                self.load_tex_slat_flow_model_1024()
                tex_slat = self.sample_tex_slat_advanced(
                    cond_1024, self.models['tex_slat_flow_model_1024'],
                    shape_slat, tex_slat_sampler_params, tex_sampler,
                    verbose = verbose,
                    dino_lock = dino_lock,
                    dino_substeps = dino_substeps,
                    dino_foundation_cap=dino_foundation_cap
                )
                
            if pbar is not None:
                pbar.update(1)
            
            if not self.keep_models_loaded:
                self.unload_tex_slat_flow_model_1024()         
            
        torch.cuda.empty_cache()
        if generate_texture_slat:
            out_mesh = self.decode_latent(shape_slat, tex_slat, res, use_tiled=use_tiled)
        else:
            out_mesh = self.decode_latent(shape_slat, None, res, use_tiled=use_tiled)
        torch.cuda.empty_cache()
        pbar.update(1)              

        return out_mesh 
                       
    @torch.inference_mode()
    def run_multiview(
        self,
        front: Image.Image,
        back: Image.Image = None,
        left: Image.Image = None,
        right: Image.Image = None,
        seed: int = 42,
        pipeline_type: str = None,
        sparse_structure_sampler_params: dict = {},
        shape_slat_sampler_params: dict = {},
        tex_slat_sampler_params: dict = {},
        max_num_tokens: int = 49152,
        sparse_structure_resolution: int = 32,
        generate_texture_slat: bool = True,
        use_tiled: bool = True,
        return_latent: bool = False,
        pbar: ProgressBar = None,
        front_axis: str = 'z',
        blend_temperature: float = 2.0,
        sampler: str = "euler",
        verbose: bool = False,
        dino_lock: float = 0.00,
        dino_substeps: int = 4,
        fill_holes: bool = True,
        hole_iterations: int = 1,
        hole_fill_algorithm = 'remove_small_holes',
        dino_foundation_cap: float = 0.92,
        keep_only_shell: bool = True,
    ) -> List[MeshWithVoxel]:
        """
        Run the pipeline with named multi-view images and spatial blending.
        """
        self.switch_samplers(sampler)
        
        if pipeline_type is None:
            pipeline_type = self.default_pipeline_type
        
        seed_all(seed)
        
        # Collect views
        views_dict = {'front': front}
        if back is not None: views_dict['back'] = back
        if left is not None: views_dict['left'] = left
        if right is not None: views_dict['right'] = right
        
        views_list = list(views_dict.keys())

        # 1. Conditioning
        # Calculate conditioning per view
        conds = {}     # 1024 or None (if 512)
        lr_conds = {}  # 512 (for cascade)
        conds_512 = {} # Explicit 512 storage for structure sampling
        conds_1024 = {}
        
        self.load_image_cond_model()
        
        if pipeline_type == '512':
             for v, img in views_dict.items():
                c = self.get_cond([img], 512)
                conds[v] = c
                conds_512[v] = c
                
        elif pipeline_type == '1024':
             for v, img in views_dict.items():
                c1024 = self.get_cond([img], 1024)
                conds[v] = c1024
                conds_1024[v] = c1024
                # Does 1024 pipeline use 512 for structure? 
                # run() says: cond_512 = get_cond(..., 512). So yes.
                conds_512[v] = self.get_cond([img], 512)
                
        elif 'cascade' in pipeline_type:
            # 1024_cascade or 1536_cascade
             for v, img in views_dict.items():
                c512 = self.get_cond([img], 512)
                c1024 = self.get_cond([img], 1024)
                lr_conds[v] = c512
                conds[v] = c1024
                conds_512[v] = c512
                conds_1024[v] = c1024
                
        if not self.keep_models_loaded:
            self.unload_image_cond_model()

        if pbar is not None:
            pbar.update(1)
        
        self.load_sparse_structure_model()          
        coords = self.sample_sparse_structure_multiview(
            conds_512, 
            views_list,
            sparse_structure_resolution,
            sampler_params=sparse_structure_sampler_params,
            front_axis=front_axis,
            blend_temperature=blend_temperature,
            verbose=verbose,
            dino_lock=dino_lock,
            dino_substeps=dino_substeps,
            fill_holes=fill_holes,
            hole_iterations=hole_iterations,
            hole_fill_algorithm=hole_fill_algorithm,
            dino_foundation_cap=dino_foundation_cap,
            keep_only_shell=keep_only_shell
        )
        
        if not self.keep_models_loaded:
            self.unload_sparse_structure_model()        
            
        if pbar is not None:
            pbar.update(1)

        # 3. Shape Slat MultiView
        shape_slat = None
        res = 0
        
        if pipeline_type == '1024_cascade':
            self.load_shape_slat_flow_model_512()
            self.load_shape_slat_flow_model_1024()
            shape_slat = self.sample_shape_slat_cascade_multiview(
                lr_conds, conds, views_list,
                self.models['shape_slat_flow_model_512'], self.models['shape_slat_flow_model_1024'],
                512, 1024,
                coords, shape_slat_sampler_params,
                max_num_tokens,
                front_axis=front_axis,
                blend_temperature=blend_temperature,
                sparse_structure_resolution = sparse_structure_resolution,
                verbose=verbose,
                dino_lock=dino_lock,
                dino_substeps=dino_substeps,
                dino_foundation_cap=dino_foundation_cap
            )
            res = 1024
            
            if not self.keep_models_loaded:
                self.unload_shape_slat_flow_model_512()
                self.unload_shape_slat_flow_model_1024()
                
        elif pipeline_type == '1536_cascade':
            self.load_shape_slat_flow_model_512()
            self.load_shape_slat_flow_model_1024()
            shape_slat = self.sample_shape_slat_cascade_multiview(
                lr_conds, conds, views_list,
                self.models['shape_slat_flow_model_512'], self.models['shape_slat_flow_model_1024'],
                512, 1536,
                coords, shape_slat_sampler_params,
                max_num_tokens,
                front_axis=front_axis,
                blend_temperature=blend_temperature,
                sparse_structure_resolution = sparse_structure_resolution,
                verbose=verbose,
                dino_lock=dino_lock,
                dino_substeps=dino_substeps,
                dino_foundation_cap=dino_foundation_cap
            )
            res = 1536
             
            if not self.keep_models_loaded:
                self.unload_shape_slat_flow_model_512()
                self.unload_shape_slat_flow_model_1024()
        
        elif pipeline_type == '512': # Single stage
             self.load_shape_slat_flow_model_512()
             shape_slat = self.sample_shape_slat_multiview(
                conds, views_list,
                self.models['shape_slat_flow_model_512'],
                coords, shape_slat_sampler_params,
                front_axis=front_axis,
                blend_temperature=blend_temperature,
                verbose=verbose,
                dino_lock=dino_lock,
                dino_substeps=dino_substeps,
                dino_foundation_cap=dino_foundation_cap
             )
             res = 512
             if not self.keep_models_loaded:
                 self.unload_shape_slat_flow_model_512()
        
        elif pipeline_type == '1024': # Single stage
             self.load_shape_slat_flow_model_1024()
             shape_slat = self.sample_shape_slat_multiview(
                conds, views_list,
                self.models['shape_slat_flow_model_1024'],
                coords, shape_slat_sampler_params,
                front_axis=front_axis,
                blend_temperature=blend_temperature,
                verbose=verbose,
                dino_lock=dino_lock,
                dino_substeps=dino_substeps,
                dino_foundation_cap=dino_foundation_cap
             )
             res = 1024
             if not self.keep_models_loaded:
                 self.unload_shape_slat_flow_model_1024()

        if pbar is not None:
            pbar.update(1)

        # Texture Slat MultiView
        tex_slat = None
        if generate_texture_slat:
            tex_model_key = 'tex_slat_flow_model_1024'
            if pipeline_type == '512':
                tex_model_key = 'tex_slat_flow_model_512'
                self.load_tex_slat_flow_model_512()
                flow_model = self.models['tex_slat_flow_model_512']
                tex_conds = conds_512
            else:
                self.load_tex_slat_flow_model_1024()
                flow_model = self.models['tex_slat_flow_model_1024']
                tex_conds = conds_1024
            
            tex_slat = self.sample_tex_slat_multiview(
                tex_conds, views_list,
                shape_slat=shape_slat, 
                flow_model=flow_model,
                sampler_params=tex_slat_sampler_params,
                front_axis=front_axis,
                blend_temperature=blend_temperature,
                verbose=verbose,
                dino_lock=dino_lock,
                dino_substeps=dino_substeps,
                dino_foundation_cap=dino_foundation_cap
            )  
             
            if not self.keep_models_loaded:
                if pipeline_type == '512':
                    self.unload_tex_slat_flow_model_512()
                else:
                    self.unload_tex_slat_flow_model_1024()

            if pbar is not None:
                pbar.update(1)
                 
        torch.cuda.empty_cache()
        if generate_texture_slat:
            out_mesh = self.decode_latent(shape_slat, tex_slat, res, use_tiled=use_tiled)
        else:
            out_mesh = self.decode_latent(shape_slat, None, res, use_tiled=use_tiled)            
        torch.cuda.empty_cache()
        
        if pbar is not None:
             pbar.update(1)
             
        if return_latent:
             return out_mesh, (shape_slat, tex_slat, res)
        else:
             return out_mesh

    @torch.no_grad()
    def sample_sparse_structure_multiview(
        self,
        conds: dict,
        views: list,
        resolution: int,
        num_samples: int = 1,
        sampler_params: dict = {},
        front_axis: str = 'z',
        blend_temperature: float = 2.0,
        fill_holes: bool = True,
        hole_structure: int = 1,
        hole_iterations: int = 1,
        hole_fill_algorithm: str = "flood_fill",
        keep_only_shell: bool = False,
        verbose: bool = True,
        dino_lock: float = 0.0,
        dino_substeps: int = 4,
        dino_foundation_cap: float = 0.92
    ) -> torch.Tensor:
        """
        Sample sparse structures with multi-view blending.
        """
        if self.low_vram:
            for v in conds:
                conds[v] = self._cond_to(conds[v], self.device)
                
        # Sample sparse structure latent
        flow_model = self.models['sparse_structure_flow_model']
        reso = flow_model.resolution
        in_channels = flow_model.in_channels
        noise = torch.randn(num_samples, in_channels, reso, reso, reso).to(self.device)
        
        # sampler = samplers.FlowEulerMultiViewGuidanceIntervalSampler(
            # sigma_min=1e-5,
            # resolution=flow_model.resolution
        # )
        sampler_class = getattr(samplers, f"Flow{self._sampler_prefix}MultiViewGuidanceIntervalSampler", samplers.FlowEulerMultiViewGuidanceIntervalSampler)
        sampler = sampler_class(
            sigma_min=1e-5,
            resolution=flow_model.resolution if hasattr(flow_model, 'resolution') else flow_model[0].resolution
        )        
        
        sampler_params = {**self.sparse_structure_sampler_params, **sampler_params}
        
        if self.low_vram:
            flow_model.to(self.device)
            
        z_s = sampler.sample(
            flow_model,
            noise,
            conds=conds,
            **sampler_params,
            views=views,
            front_axis=front_axis,
            blend_temperature=blend_temperature,            
            verbose=verbose,
            dino_lock=dino_lock,
            dino_substeps=dino_substeps,
            dino_foundation_cap=dino_foundation_cap,
            tqdm_desc="Sampling sparse structure (MultiView)",
        ).samples
        
        if self.low_vram:
            flow_model.cpu()
            self._cleanup_cuda()
            
        # Decode sparse structure latent
        decoder = self.models['sparse_structure_decoder']
        if self.low_vram:
            decoder.to(self.device)
            
        # Standard decoding logic from sample_sparse_structure
        decoded = decoder(z_s) > 0
        
        if self.low_vram:
            decoder.cpu()
            self._cleanup_cuda()
            
        # if resolution != decoded.shape[2]:
            # ratio = decoded.shape[2] // resolution
            # decoded = torch.nn.functional.max_pool3d(decoded.float(), ratio, ratio, 0) > 0.5
        if resolution != decoded.shape[2]:
            if resolution < decoded.shape[2]:
                ratio = decoded.shape[2] // resolution
                decoded = torch.nn.functional.max_pool3d(decoded.float(), ratio, ratio, 0) > 0.5
            else:
                decoded = torch.nn.functional.interpolate(decoded.float(), size=(resolution, resolution, resolution), mode='nearest') > 0.5            

        # Optionally fill holes in the sparse voxel grid using the selected algorithm
        if fill_holes:
            try:
                from scipy.ndimage import binary_closing, label, binary_fill_holes
                arr = decoded.cpu().numpy()
                if arr.ndim == 5:
                    arr = arr[:, 0]
                closed = np.zeros_like(arr)
                for b in range(arr.shape[0]):
                    filled = arr[b].astype(np.bool_)
                    inv = ~filled
                    labeled, num_features = label(inv)
                    border_mask = np.zeros_like(inv)
                    border_mask[0,:,:] = border_mask[-1,:,:] = 1
                    border_mask[:,0,:] = border_mask[:,-1,:] = 1
                    border_mask[:,:,0] = border_mask[:,:,-1] = 1
                    border_labels = np.unique(labeled[border_mask==1])
                    holes = np.isin(labeled, border_labels, invert=True) & (labeled > 0)
                    n_holes = np.unique(labeled[holes]).size
                    print(f"[Sparse HoleFill] Batch {b}: Found {n_holes} holes before filling.")
                    if hole_fill_algorithm == "morphological_closing":
                        closed[b] = binary_closing(arr[b], structure=np.ones((hole_structure,)*3), iterations=hole_iterations)
                    elif hole_fill_algorithm == "flood_fill":
                        # Robust structure-preserving hole filling:
                        # 1. Morphological closing to connect small gaps
                        # 2. Fill internal holes
                        # 3. Keep only the largest connected component
                        from scipy.ndimage import binary_closing, label, binary_fill_holes
                        # Step 1: Morphological closing (small structure, 1 iter)
                        closed1 = binary_closing(arr[b], structure=np.ones((hole_structure,)*3), iterations=hole_iterations)
                        # Step 2: Fill internal holes
                        filled = binary_fill_holes(closed1)
                        # Step 3: Keep only the largest connected component
                        labeled, num = label(filled)
                        if num > 0:
                            sizes = np.bincount(labeled.ravel())
                            sizes[0] = 0  # background
                            largest = sizes.argmax()
                            closed[b] = (labeled == largest)
                        else:
                            closed[b] = filled                      
                    elif hole_fill_algorithm == "remove_small_holes":
                        # Remove small holes by area (2D slices)
                        from skimage.morphology import remove_small_holes
                        # Apply per-slice (z axis)
                        temp = np.copy(arr[b])
                        for z in range(temp.shape[0]):
                            temp[z] = remove_small_holes(temp[z].astype(bool), area_threshold=hole_structure**2)
                        closed[b] = temp
                    else:
                        print(f"[Sparse HoleFill] Unknown algorithm: {hole_fill_algorithm}, skipping.")
                        closed[b] = arr[b]
                    # Count holes after filling
                    filled2 = closed[b].astype(np.bool_)
                    inv2 = ~filled2
                    labeled2, num_features2 = label(inv2)
                    border_labels2 = np.unique(labeled2[border_mask==1])
                    holes2 = np.isin(labeled2, border_labels2, invert=True) & (labeled2 > 0)
                    n_holes2 = np.unique(labeled2[holes2]).size
                    print(f"[Sparse HoleFill] Batch {b}: {n_holes-n_holes2} holes filled, {n_holes2} remain after filling.")

                    # Optionally remove deeply interior voxels, keeping surface and near-surface structure
                    if keep_only_shell:
                        from scipy.ndimage import binary_erosion

                        filled = closed[b].astype(np.bool_)
                        before_count = int(filled.sum())
                        struct = np.ones((3, 3, 3), dtype=bool)
                        # Erode twice: only voxels surviving 2 erosion passes are >=2 layers deep
                        # This preserves thin structures (e.g. necks with 3x3 cross-section)
                        eroded = binary_erosion(filled, structure=struct, border_value=0)
                        eroded = binary_erosion(eroded, structure=struct, border_value=0)
                        # Remove only deeply interior voxels (>=2 layers from any surface)
                        shell = filled & ~eroded
                        closed[b] = shell
                        after_count = int(shell.sum())
                        if verbose:
                            print(f"[Sparse Shell] Batch {b}: {before_count} -> {after_count} voxels (removed {before_count - after_count} deeply interior)")

                decoded = torch.from_numpy(closed).to(decoded.device)


                # Debug: print tensor info before extracting coordinates
                if verbose:
                    print(f"[Sparse HoleFill] decoded shape: {decoded.shape}, dtype: {decoded.dtype}, device: {decoded.device}")
                    print(f"[Sparse HoleFill] decoded min: {decoded.min().item()}, max: {decoded.max().item()}, unique: {torch.unique(decoded)}")
                # Safety: ensure tensor is contiguous and on CPU for argwhere
                decoded = decoded.contiguous().cpu()

            except ImportError:
                print("[Warning] scipy or skimage not installed, skipping hole filling.")
            except Exception as e:
                print(f"[Warning] Hole filling failed: {e}")

            try:
                coords = torch.argwhere(decoded)[:, [0, 1, 2, 3]].int()
            except Exception as e:
                print(f"[Sparse HoleFill] Error in torch.argwhere: {e}")
                raise

            if verbose:
                print(f"[Sparse HoleFill] coords shape: {coords.shape}, min: {coords.min(dim=0).values.tolist() if coords.numel()>0 else 'empty'}, max: {coords.max(dim=0).values.tolist() if coords.numel()>0 else 'empty'}")

            if coords.numel() == 0:
                raise RuntimeError("No voxels remain after hole filling/shell extraction. The mask is empty. Adjust your input, mask, or hole filling parameters.")
        else:
            coords = torch.argwhere(decoded)[:, [0, 2, 3, 4]].int()

        coords = coords.cpu()

        del decoded
        del z_s
        if self.low_vram:
            for v in conds:
                conds[v] = self._cond_cpu(conds[v])
            self._cleanup_cuda()
            
        return coords

    @torch.no_grad()
    def sample_shape_slat_multiview(
        self,
        conds: dict,
        views: list,
        flow_model,
        coords: torch.Tensor,
        sampler_params: dict = {},
        front_axis: str = 'z',
        blend_temperature: float = 2.0,
        verbose: bool = False,
        dino_lock: float = 0.00,
        dino_substeps: int = 4,
        dino_foundation_cap: float = 0.92
    ) -> SparseTensor:
        if self.low_vram:
            for v in conds:
                conds[v] = self._cond_to(conds[v], self.device)

        coords_dev = coords.to(self.device)                         
        noise = SparseTensor(
            feats=torch.randn(coords.shape[0], flow_model.in_channels, device=self.device),
            coords=coords_dev,
        )
        
        # sampler = samplers.FlowEulerMultiViewGuidanceIntervalSampler(
            # sigma_min=1e-5,
            # resolution=flow_model.resolution,
        # )
        sampler_class = getattr(samplers, f"Flow{self._sampler_prefix}MultiViewGuidanceIntervalSampler", samplers.FlowEulerMultiViewGuidanceIntervalSampler)
        sampler = sampler_class(
            sigma_min=1e-5,
            resolution=flow_model.resolution if hasattr(flow_model, 'resolution') else flow_model[0].resolution
        )        
        
        sampler_params = {**self.shape_slat_sampler_params, **sampler_params}
        
        if self.low_vram:
            flow_model.to(self.device)
            
        slat = sampler.sample(
            flow_model,
            noise,
            conds=conds,
            **sampler_params,
            views=views,
            front_axis=front_axis,
            blend_temperature=blend_temperature,            
            verbose=verbose,
            dino_lock = dino_lock,
            dino_substeps = dino_substeps,
            dino_foundation_cap = dino_foundation_cap,
            tqdm_desc="Sampling shape SLat (MultiView)",
        ).samples
        
        if self.low_vram:
            flow_model.cpu()
            self._cleanup_cuda()                                

        std = torch.tensor(self.shape_slat_normalization['std'])[None].to(slat.device)
        mean = torch.tensor(self.shape_slat_normalization['mean'])[None].to(slat.device)
        slat = slat * std + mean
        
        del coords_dev
        if self.low_vram:
            for v in conds:
                conds[v] = self._cond_cpu(conds[v])
            self._cleanup_cuda()

        return slat

    @torch.no_grad()
    def sample_shape_slat_cascade_multiview(
        self,
        lr_conds: dict,
        conds: dict,
        views: list,
        flow_model_lr,
        flow_model,
        lr_resolution: int,
        resolution: int,
        coords: torch.Tensor,
        sampler_params: dict = {},
        max_num_tokens: int = 49152,
        front_axis: str = 'z',
        blend_temperature: float = 2.0,
        sparse_structure_resolution: int = 32,
        verbose: bool = False,
        dino_lock: float = 0.00,
        dino_substeps: int = 4,
        dino_foundation_cap: float = 0.92
    ) -> SparseTensor:
        # LR
        if self.low_vram:
            for v in lr_conds:
                lr_conds[v] = self._cond_to(lr_conds[v], self.device)
            for v in conds:
                conds[v] = self._cond_to(conds[v], self.device)

        coords_dev = coords.to(self.device)                         
        noise = SparseTensor(
            feats=torch.randn(coords.shape[0], flow_model_lr.in_channels, device=self.device),
            coords=coords_dev,
        )
        
        # sampler_lr = samplers.FlowEulerMultiViewGuidanceIntervalSampler(
            # sigma_min=1e-5,
            # resolution=flow_model_lr.resolution,
        # )
        sampler_class = getattr(samplers, f"Flow{self._sampler_prefix}MultiViewGuidanceIntervalSampler", samplers.FlowEulerMultiViewGuidanceIntervalSampler)
        sampler_lr = sampler_class(
            sigma_min=1e-5,
            resolution=flow_model.resolution if hasattr(flow_model, 'resolution') else flow_model[0].resolution
        )        
        
        sampler_params_combined = {**self.shape_slat_sampler_params, **sampler_params}
        
        if self.low_vram:
            flow_model_lr.to(self.device)
            
        slat = sampler_lr.sample(
            flow_model_lr,
            noise,
            conds=lr_conds,
            **sampler_params_combined,
            views=views,
            front_axis=front_axis,
            blend_temperature=blend_temperature,            
            verbose=verbose,
            dino_lock=dino_lock,
            dino_substeps=dino_substeps,
            dino_foundation_cap=dino_foundation_cap,
            tqdm_desc="Sampling shape SLat (MultiView LR)",
        ).samples
        
        if self.low_vram:
            flow_model_lr.cpu()
            self._cleanup_cuda()                                
        
        std = torch.tensor(self.shape_slat_normalization['std'])[None].to(slat.device)
        mean = torch.tensor(self.shape_slat_normalization['mean'])[None].to(slat.device)
        slat = slat * std + mean
        del coords_dev
        
        # Upsample logic
        self.load_shape_slat_decoder()
        if self.low_vram:
            self.models['shape_slat_decoder'].to(self.device)
            self.models['shape_slat_decoder'].low_vram = True
        hr_coords = self.models['shape_slat_decoder'].upsample(slat, upsample_times=4)
        if self.low_vram:
            self.models['shape_slat_decoder'].cpu()
            self.models['shape_slat_decoder'].low_vram = False
        
        ratio = sparse_structure_resolution / 32
        
        hr_resolution = resolution
        while True:
            quant_coords = torch.cat([
                hr_coords[:, :1],
                ((hr_coords[:, 1:] + 0.5) / (lr_resolution * ratio) * (hr_resolution // 16)).int(),
            ], dim=1)
            coords = quant_coords.unique(dim=0)
            num_tokens = coords.shape[0]
            if num_tokens < max_num_tokens:
                if hr_resolution != resolution:
                    print(f"Due to the limited number of tokens, the resolution is reduced to {hr_resolution}.")
                break
            hr_resolution -= 128
            if hr_resolution < 1024 and resolution >= 1024:
                hr_resolution = 1024
                break
            if hr_resolution < 512:
                hr_resolution = 512
                break

        # HR
        # sampler_hr = samplers.FlowEulerMultiViewGuidanceIntervalSampler(
            # sigma_min=1e-5,
            # resolution=flow_model.resolution,
        # )
        sampler_class = getattr(samplers, f"Flow{self._sampler_prefix}MultiViewGuidanceIntervalSampler", samplers.FlowEulerMultiViewGuidanceIntervalSampler)
        sampler_hr = sampler_class(
            sigma_min=1e-5,
            resolution=flow_model.resolution if hasattr(flow_model, 'resolution') else flow_model[0].resolution
        )        
        
        coords_dev = coords.to(self.device).contiguous()
        noise = SparseTensor(
            feats=torch.randn(coords_dev.shape[0], flow_model.in_channels, device=self.device),
            coords=coords_dev,
        )
        
        if self.low_vram:
            flow_model.to(self.device)
            
        d_slat = sampler_hr.sample(
            flow_model,
            noise,
            conds=conds,
            **sampler_params_combined,
            views=views,
            front_axis=front_axis,
            blend_temperature=blend_temperature,            
            verbose=verbose,
            dino_lock=dino_lock,
            dino_substeps=dino_substeps,
            dino_foundation_cap=dino_foundation_cap,
            tqdm_desc="Sampling shape SLat (MultiView HR)",
        ).samples
        
        if self.low_vram:
            flow_model.cpu()
            self._cleanup_cuda()
            
        slat = d_slat * std + mean
        
        if self.low_vram:
            for v in lr_conds:
                lr_conds[v] = self._cond_cpu(lr_conds[v])
            for v in conds:
                conds[v] = self._cond_cpu(conds[v])
            self._cleanup_cuda()
            
        return slat

    @torch.no_grad()
    def sample_tex_slat_multiview(
        self,
        conds: dict,
        views: list,
        shape_slat: SparseTensor,
        flow_model,
        sampler_params: dict = {},
        front_axis: str = 'z',
        blend_temperature: float = 2.0,
        verbose: bool = False,
        dino_lock: float = 0.00,
        dino_substeps: int = 4,
        dino_foundation_cap: float = 0.92
    ) -> SparseTensor:
        """
        Sample structured latent for texture with multi-view blending.
        """
        if self.low_vram:
            for v in conds:
                conds[v] = self._cond_to(conds[v], self.device)

        # Normalize shape slat for conditioning
        std = torch.tensor(self.shape_slat_normalization['std'])[None].to(shape_slat.device)
        mean = torch.tensor(self.shape_slat_normalization['mean'])[None].to(shape_slat.device)
        shape_slat_normalized = (shape_slat - mean) / std

        #coords = shape_slat.coords
        #coords_dev = coords.to(self.device)
        
        # Calculate noise channels: total input - concat cond channels
        in_channels = flow_model.in_channels if isinstance(flow_model, nn.Module) else flow_model[0].in_channels
        noise_channels = in_channels - shape_slat.feats.shape[1]
        
        # noise = SparseTensor(
            # feats=torch.randn(coords.shape[0], noise_channels, device=self.device),
            # coords=coords_dev,
        # )
        noise = shape_slat.replace(feats=torch.randn(shape_slat.coords.shape[0], in_channels - shape_slat.feats.shape[1]).to(self.device))
        
        sampler_params = {**self.tex_slat_sampler_params, **sampler_params}
        
        # sampler = samplers.FlowEulerMultiViewGuidanceIntervalSampler(
            # sigma_min=1e-5,
            # resolution=flow_model.resolution,
        # )
        sampler_class = getattr(samplers, f"Flow{self._sampler_prefix}MultiViewGuidanceIntervalSampler", samplers.FlowEulerMultiViewGuidanceIntervalSampler)
        sampler = sampler_class(
            sigma_min=1e-5,
            resolution=flow_model.resolution if hasattr(flow_model, 'resolution') else flow_model[0].resolution
        )          
        
        if self.low_vram:
            flow_model.to(self.device)
            
        slat = sampler.sample(
            flow_model,
            noise,
            conds=conds,
            **sampler_params,
            views=views,
            front_axis=front_axis,
            blend_temperature=blend_temperature,
            concat_cond=shape_slat_normalized,            
            verbose=verbose,
            dino_lock=dino_lock,
            dino_substeps=dino_substeps,
            dino_foundation_cap=dino_foundation_cap,
            tqdm_desc="Sampling texture SLat (MultiView)",
        ).samples
        
        if self.low_vram:
            flow_model.cpu()
            self._cleanup_cuda()

        std = torch.tensor(self.tex_slat_normalization['std'])[None].to(slat.device)
        mean = torch.tensor(self.tex_slat_normalization['mean'])[None].to(slat.device)
        slat = slat * std + mean
        
        #del coords_dev
        if self.low_vram:
            for v in conds:
                conds[v] = self._cond_cpu(conds[v])
            self._cleanup_cuda()
            
        return slat

    def preprocess_mesh(self, mesh: trimesh.Trimesh) -> trimesh.Trimesh:
        """
        Preprocess the input mesh.
        """
        mesh = mesh.copy()
        vertices = mesh.vertices.copy()
        
        vertices_min = vertices.min(axis=0)
        vertices_max = vertices.max(axis=0)
        center = (vertices_min + vertices_max) / 2
        scale = 0.99999 / (vertices_max - vertices_min).max()
        vertices = (vertices - center) * scale
        tmp = vertices[:, 1].copy()
        vertices[:, 1] = -vertices[:, 2]
        vertices[:, 2] = tmp
        assert np.all(vertices >= -0.5) and np.all(vertices <= 0.5), 'vertices out of range'
        
        mesh.vertices = vertices
        return mesh

    @torch.no_grad()
    def encode_shape_slat(
        self,
        mesh: trimesh.Trimesh,
        resolution: int = 1024,
    ) -> SparseTensor:
        """
        Encode the meshes to structured latent.

        Args:
            mesh (trimesh.Trimesh): The mesh to encode.
            resolution (int): The resolution of mesh
        
        Returns:
            SparseTensor: The encoded structured latent.
        """
        print('Converting mesh to flexible dual grid ...')        
        vertices = torch.from_numpy(mesh.vertices).float()
        faces = torch.from_numpy(mesh.faces).long()
        
        voxel_indices, dual_vertices, intersected = o_voxel.convert.mesh_to_flexible_dual_grid(
            vertices.cpu(), faces.cpu(),
            grid_size=resolution,
            aabb=[[-0.5,-0.5,-0.5],[0.5,0.5,0.5]],
            face_weight=1.0,
            boundary_weight=0.2,
            regularization_weight=1e-2,
            timing=True,
        )
            
        vertices = SparseTensor(
            feats=dual_vertices * resolution - voxel_indices,
            coords=torch.cat([torch.zeros_like(voxel_indices[:, 0:1]), voxel_indices], dim=-1)
        ).to(self.device)
        intersected = vertices.replace(intersected).to(self.device)
            
        self.load_shape_slat_encoder()
            
        if self.low_vram:
            self.models['shape_slat_encoder'].to(self.device)
        shape_slat = self.models['shape_slat_encoder'](vertices, intersected)
        if self.low_vram:
            self.models['shape_slat_encoder'].cpu()
            
        if not self.keep_models_loaded:
            self.unload_shape_slat_encoder()
            
        return shape_slat

    def postprocess_mesh(
        self,
        mesh: trimesh.Trimesh,
        pbr_voxel: SparseTensor,
        resolution: int = 1024,
        texture_size: int = 1024,
        texture_alpha_mode = 'OPAQUE',
        double_side_material = True,
        bake_on_vertices = False,
        use_custom_normals = False,
        mesh_cluster_threshold_cone_half_angle_rad = 60.0,
        inpainting = 'telea',
    ):        
        vertices = mesh.vertices
        faces = mesh.faces
        normals = np.asarray(mesh.vertex_normals).copy()
        
        vertices_torch = torch.from_numpy(vertices).float().cuda()
        faces_torch = torch.from_numpy(faces).int().cuda()
        if hasattr(mesh, 'visual') and hasattr(mesh.visual, 'uv') and mesh.visual.uv is not None:
            uvs = mesh.visual.uv.copy()
            uvs[:, 1] = 1 - uvs[:, 1]
            uvs_torch = torch.from_numpy(uvs).float().cuda()
        else:
            _cumesh = cumesh.CuMesh()
            _cumesh.init(vertices_torch, faces_torch)
            print('Unwrapping mesh ...')
            vertices_torch, faces_torch, uvs_torch, vmap = _cumesh.uv_unwrap(
                compute_charts_kwargs={
                    "threshold_cone_half_angle_rad": np.radians(mesh_cluster_threshold_cone_half_angle_rad),
                    "refine_iterations": 0,
                    "global_iterations": 1,
                    "smooth_strength": 1,
                },
                return_vmaps=True,
                verbose=True,
            )
            
            del _cumesh
            gc.collect()      
            
            vertices_torch = vertices_torch.cuda()
            faces_torch = faces_torch.cuda()
            uvs_torch = uvs_torch.cuda()
            vertices = vertices_torch.cpu().numpy()
            faces = faces_torch.cpu().numpy()
            uvs = uvs_torch.cpu().numpy()
            normals = normals[vmap.cpu().numpy()]

        # --- Branch: Bake On Vertices (skip UV unwrapping and texture creation) ---
        if bake_on_vertices:
            aabb = [[-0.5, -0.5, -0.5], [0.5, 0.5, 0.5]]
            
            # --- Input Normalization (AABB, Voxel Size, Grid Size) ---
            if isinstance(aabb, (list, tuple)):
                aabb = np.array(aabb)
            if isinstance(aabb, np.ndarray):
                aabb = torch.tensor(aabb, dtype=torch.float32, device=pbr_voxel.coords.device)

            voxel_size = 1 / resolution

            # Calculate grid dimensions based on AABB and voxel size                
            if voxel_size is not None:
                if isinstance(voxel_size, float):
                    voxel_size = [voxel_size, voxel_size, voxel_size]
                if isinstance(voxel_size, (list, tuple)):
                    voxel_size = np.array(voxel_size)
                if isinstance(voxel_size, np.ndarray):
                    voxel_size = torch.tensor(voxel_size, dtype=torch.float32, device=pbr_voxel.coords.device)
                grid_size = ((aabb[1] - aabb[0]) / voxel_size).round().int()
            else:
                if isinstance(grid_size, int):
                    grid_size = [grid_size, grid_size, grid_size]
                if isinstance(grid_size, (list, tuple)):
                    grid_size = np.array(grid_size)
                if isinstance(grid_size, np.ndarray):
                    grid_size = torch.tensor(grid_size, dtype=torch.int32, device=pbr_voxel.coords.device)
                voxel_size = (aabb[1] - aabb[0]) / grid_size
            
            print('Baking colors on vertices...')
            out_vertices = vertices_torch
            out_faces = faces_torch
            out_normals = normals           
            
            # Sample attributes directly at vertex positions from the voxel grid
            # No BVH mapping needed - the voxel grid contains all the color information
            vertex_attrs = grid_sample_3d(
                pbr_voxel.feats,
                pbr_voxel.coords,
                shape=torch.Size([*pbr_voxel.shape, *pbr_voxel.spatial_shape]),
                grid=((out_vertices - aabb[0]) / voxel_size).reshape(1, -1, 3),
                mode='trilinear',
            )
            
            # Extract base color and alpha per vertex (vertex_attrs shape: N_vertices x C)
            base_color_idx = self.pbr_attr_layout['base_color']
            alpha_idx = self.pbr_attr_layout['alpha']
            
            # Get RGB values and squeeze any extra dimensions to get (N, 3)
            vertex_colors_rgb = vertex_attrs[..., base_color_idx].cpu().numpy()
            vertex_colors_rgb = np.squeeze(vertex_colors_rgb)  # Remove batch dims if any
            if vertex_colors_rgb.ndim == 1:
                vertex_colors_rgb = vertex_colors_rgb[None, :]  # Ensure at least 2D
            vertex_colors_rgb = np.clip(vertex_colors_rgb * 255, 0, 255).astype(np.uint8)
            
            # Handle alpha based on texture_alpha_mode
            if texture_alpha_mode == "OPAQUE":
                # For OPAQUE mode, use full alpha (255)
                vertex_alpha = np.full((vertex_colors_rgb.shape[0], 1), 255, dtype=np.uint8)
            else:
                vertex_alpha = vertex_attrs[..., alpha_idx].cpu().numpy()
                vertex_alpha = np.squeeze(vertex_alpha)  # Remove batch dims if any
                vertex_alpha = np.clip(vertex_alpha * 255, 0, 255).astype(np.uint8)
                # Ensure alpha is 2D with shape (N, 1)
                if vertex_alpha.ndim == 1:
                    vertex_alpha = vertex_alpha[:, None]
            
            # Combine into RGBA
            vertex_colors_rgba = np.concatenate([vertex_colors_rgb, vertex_alpha], axis=-1)
            
            print("Finalizing mesh with vertex colors...")
            
            vertices_np = out_vertices.cpu().numpy()
            faces_np = out_faces.cpu().numpy()
            normals_np = out_normals
            
            # Swap Y and Z axes, invert Y (common conversion for GLB compatibility)
            vertices_np[:, 1], vertices_np[:, 2] = vertices_np[:, 2].copy(), -vertices_np[:, 1].copy()
            normals_np[:, 1], normals_np[:, 2] = normals_np[:, 2].copy(), -normals_np[:, 1].copy()
            
            # Create mesh with vertex colors using ColorVisuals
            if use_custom_normals:
                textured_mesh = trimesh.Trimesh(
                    vertices=vertices_np,
                    faces=faces_np,
                    vertex_normals=normals_np,
                    vertex_colors=vertex_colors_rgba,
                    process=False,
                )
            else:
                textured_mesh = trimesh.Trimesh(
                    vertices=vertices_np,
                    faces=faces_np,
                    vertex_colors=vertex_colors_rgba,
                    process=False,
                )                
            
            # Return empty placeholder textures for vertex color mode
            placeholder_texture = Image.new('RGBA', (1, 1), (0, 0, 0, 0))
            return (textured_mesh, placeholder_texture, placeholder_texture,)
                
        # rasterize
        print('Finalizing mesh ...')
        ctx = dr.RasterizeCudaContext()
        uvs_torch = torch.cat([uvs_torch * 2 - 1, torch.zeros_like(uvs_torch[:, :1]), torch.ones_like(uvs_torch[:, :1])], dim=-1).unsqueeze(0)
        rast, _ = dr.rasterize(
            ctx, uvs_torch, faces_torch,
            resolution=[texture_size, texture_size],
        )
        
        torch.cuda.synchronize()
        
        mask = rast[0, ..., 3] > 0
        pos = dr.interpolate(vertices_torch.unsqueeze(0), rast, faces_torch)[0][0]
        
        attrs = torch.zeros(texture_size, texture_size, pbr_voxel.shape[1], device=self.device)
        attrs[mask] = flex_gemm.ops.grid_sample.grid_sample_3d(
            pbr_voxel.feats,
            pbr_voxel.coords,
            shape=torch.Size([*pbr_voxel.shape, *pbr_voxel.spatial_shape]),
            grid=((pos[mask] + 0.5) * resolution).reshape(1, -1, 3),
            mode='trilinear',
        )
        
        torch.cuda.synchronize()
        
        # construct mesh
        mask = mask.cpu().numpy()
        base_color = np.clip(attrs[..., self.pbr_attr_layout['base_color']].cpu().numpy() * 255, 0, 255).astype(np.uint8)
        metallic = np.clip(attrs[..., self.pbr_attr_layout['metallic']].cpu().numpy() * 255, 0, 255).astype(np.uint8)
        roughness = np.clip(attrs[..., self.pbr_attr_layout['roughness']].cpu().numpy() * 255, 0, 255).astype(np.uint8)
        alpha = np.clip(attrs[..., self.pbr_attr_layout['alpha']].cpu().numpy() * 255, 0, 255).astype(np.uint8)
        
        # extend
        if inpainting == 'telea':
            inpainting = cv2.INPAINT_TELEA
        else:
            inpainting = cv2.INPAINT_NS
        
        mask = (~mask).astype(np.uint8)
        base_color = cv2.inpaint(base_color, mask, 3, inpainting)
        metallic = cv2.inpaint(metallic, mask, 1, inpainting)[..., None]
        roughness = cv2.inpaint(roughness, mask, 1, inpainting)[..., None]
        alpha = cv2.inpaint(alpha, mask, 1, inpainting)[..., None]
        
        baseColorTexture = Image.fromarray(np.concatenate([base_color, alpha], axis=-1))
        metallicRoughnessTexture = Image.fromarray(np.concatenate([np.zeros_like(metallic), roughness, metallic], axis=-1))
        
        material = trimesh.visual.material.PBRMaterial(
            baseColorTexture=baseColorTexture,
            baseColorFactor=np.array([255, 255, 255, 255], dtype=np.uint8),
            metallicRoughnessTexture=metallicRoughnessTexture,
            metallicFactor=1.0,
            roughnessFactor=1.0,
            alphaMode=texture_alpha_mode,
            doubleSided=True,
        )

        # Swap Y and Z axes, invert Y (common conversion for GLB compatibility)
        vertices[:, 1], vertices[:, 2] = vertices[:, 2], -vertices[:, 1]
        normals[:, 1], normals[:, 2] = normals[:, 2], -normals[:, 1]
        uvs[:, 1] = 1 - uvs[:, 1] # Flip UV V-coordinate
        
        if use_custom_normals:
            textured_mesh = trimesh.Trimesh(
                vertices=vertices,
                faces=faces,
                vertex_normals=normals,
                process=False,
                visual=trimesh.visual.TextureVisuals(uv=uvs, material=material)
            )
        else:
            textured_mesh = trimesh.Trimesh(
                vertices=vertices,
                faces=faces,
                process=False,
                visual=trimesh.visual.TextureVisuals(uv=uvs, material=material)
            )
            
        return textured_mesh, baseColorTexture, metallicRoughnessTexture

    @torch.inference_mode()
    def texture_mesh(
        self,
        mesh: trimesh.Trimesh,
        image: Image.Image,
        seed: int = 42,
        tex_slat_sampler_params: dict = {},
        resolution: int = 1024,
        texture_size: int = 2048,
        texture_alpha_mode = 'OPAQUE',
        double_side_material = True,
        max_views = 4,
        bake_on_vertices = False,
        use_custom_normals = False,
        mesh_cluster_threshold_cone_half_angle_rad=60.0,
        sampler: str = 'euler',
        inpainting: str = 'telea',
        verbose: bool = False,
        dino_lock: float = 0.0,
        dino_substeps: int = 4,
        dino_foundation_cap: float = 0.92
    ):
        self.switch_samplers(sampler)
        
        mesh = self.preprocess_mesh(mesh)
        seed_all(seed)
        
        # Accept either a single PIL image or a list of PIL images (multi-view)
        if isinstance(image, (list, tuple)):
            images = list(image)
        else:
            images = [image]
        
        self.load_image_cond_model()        
        cond_resolution = resolution
        if cond_resolution>1024:
            cond_resolution = 1024
            
        cond = self.get_cond(images, cond_resolution, max_views = max_views)
        
        if not self.keep_models_loaded:
            self.unload_image_cond_model()
        
        shape_slat = self.encode_shape_slat(mesh, resolution)
        
        if resolution==512:            
            self.unload_tex_slat_flow_model_1024()
            self.load_tex_slat_flow_model_512()
            tex_model = self.models['tex_slat_flow_model_512']
            
            tex_slat = self.sample_tex_slat(
                cond, tex_model,
                shape_slat, tex_slat_sampler_params,
                verbose = verbose,
                dino_lock = dino_lock,
                dino_substeps = dino_substeps,
                dino_foundation_cap = dino_foundation_cap
            )
            
            if not self.keep_models_loaded:
                self.unload_tex_slat_flow_model_512()
        else:
            self.unload_tex_slat_flow_model_512()
            self.load_tex_slat_flow_model_1024()
            tex_model = self.models['tex_slat_flow_model_1024']           
            
            tex_slat = self.sample_tex_slat(
                cond, tex_model,
                shape_slat, tex_slat_sampler_params,
                verbose = verbose,
                dino_lock = dino_lock,
                dino_substeps = dino_substeps,
                dino_foundation_cap = dino_foundation_cap
            )
            
            if not self.keep_models_loaded:
                self.unload_shape_slat_flow_model_1024()

        torch.cuda.empty_cache()
        pbr_voxel = self.decode_tex_slat(tex_slat)
        torch.cuda.empty_cache()
        
        out_mesh, baseColorTexture, metallicRoughnessTexture = self.postprocess_mesh(mesh, pbr_voxel, resolution, texture_size, texture_alpha_mode, double_side_material, bake_on_vertices, use_custom_normals, mesh_cluster_threshold_cone_half_angle_rad, inpainting)
        return out_mesh, baseColorTexture, metallicRoughnessTexture
        
    @torch.inference_mode()
    def texture_mesh_multiview(
        self,
        mesh: trimesh.Trimesh,
        front: Image.Image,
        back: Image.Image,
        left: Image.Image,
        right: Image.Image,
        seed: int = 42,
        tex_slat_sampler_params: dict = {},
        resolution: int = 1024,
        texture_size: int = 2048,
        texture_alpha_mode = 'OPAQUE',
        double_side_material = True,
        bake_on_vertices = False,
        use_custom_normals = False,
        mesh_cluster_threshold_cone_half_angle_rad=60.0,
        front_axis: str = 'z',
        blend_temperature: float = 2.0,
        sampler: str = 'euler',
        inpainting: str = 'telea',
        verbose: bool = False,
        dino_lock: float = 0.0,
        dino_substeps: int = 4,
        dino_foundation_cap: float = 0.92
    ):
        self.switch_samplers(sampler)
        
        mesh = self.preprocess_mesh(mesh)
        seed_all(seed)
        
        self.load_image_cond_model()        
        # Collect views
        views_dict = {'front': front}
        if back is not None: views_dict['back'] = back
        if left is not None: views_dict['left'] = left
        if right is not None: views_dict['right'] = right
        
        views_list = list(views_dict.keys())

        # 1. Conditioning
        # Calculate conditioning per view
        conds = {}
        
        self.load_image_cond_model()
        
        if resolution == 512:
             for v, img in views_dict.items():
                c = self.get_cond([img], 512)
                conds[v] = c
        else:
             for v, img in views_dict.items():
                c = self.get_cond([img], 1024)
                conds[v] = c
        
        if not self.keep_models_loaded:
            self.unload_image_cond_model()
        
        shape_slat = self.encode_shape_slat(mesh, resolution)
        
        if resolution==512:
            self.unload_tex_slat_flow_model_1024()
            self.load_tex_slat_flow_model_512()
            tex_model = self.models['tex_slat_flow_model_512']
            
            tex_slat = self.sample_tex_slat_multiview(
                conds, views_list,
                shape_slat=shape_slat, 
                flow_model=tex_model,
                sampler_params=tex_slat_sampler_params,
                front_axis=front_axis,
                blend_temperature=blend_temperature,
                verbose=verbose,
                dino_lock=dino_lock,
                dino_substeps=dino_substeps,
                dino_foundation_cap=dino_foundation_cap
            )            
            
            if not self.keep_models_loaded:
                self.unload_tex_slat_flow_model_512()
        else:
            self.unload_tex_slat_flow_model_512()
            self.load_tex_slat_flow_model_1024()
            tex_model = self.models['tex_slat_flow_model_1024']
            
            tex_slat = self.sample_tex_slat_multiview(
                conds, views_list,
                shape_slat=shape_slat, 
                flow_model=tex_model,
                sampler_params=tex_slat_sampler_params,
                front_axis=front_axis,
                blend_temperature=blend_temperature,
                verbose=verbose,
                dino_lock=dino_lock,
                dino_substeps=dino_substeps,
                dino_foundation_cap=dino_foundation_cap
            )                          
            
            if not self.keep_models_loaded:
                self.unload_shape_slat_flow_model_1024()
                
        torch.cuda.empty_cache()
        pbr_voxel = self.decode_tex_slat(tex_slat)
        torch.cuda.empty_cache()
        
        out_mesh, baseColorTexture, metallicRoughnessTexture = self.postprocess_mesh(mesh, pbr_voxel, resolution, texture_size, texture_alpha_mode, double_side_material, bake_on_vertices, use_custom_normals, mesh_cluster_threshold_cone_half_angle_rad, inpainting)
        return out_mesh, baseColorTexture, metallicRoughnessTexture        

    # Reorientations that map an incoming mesh into the frame preprocess_mesh expects,
    # named and defined exactly like Trellis2MeshWithVoxelToTrimesh's reorient_vertices.
    # The pipeline's own TRIMESH frame is Z-up (that node's "90 degrees" output), so a
    # plain Y-up glb needs "90 degrees" applied again to get there.
    MESH_ORIENTATIONS = {
        'none': np.eye(4),
        '90 degrees': np.array([[1., 0., 0., 0.],      # (x, y, z) -> (x, z, -y)
                                [0., 0., 1., 0.],
                                [0., -1., 0., 0.],
                                [0., 0., 0., 1.]]),
        '-90 degrees': np.array([[1., 0., 0., 0.],     # (x, y, z) -> (x, -z, y)
                                 [0., 0., -1., 0.],
                                 [0., 1., 0., 0.],
                                 [0., 0., 0., 1.]]),
    }

    def _view_silhouettes(self, mesh: trimesh.Trimesh, views: dict) -> List[np.ndarray]:
        """
        Rasterise the mesh through each view's conditioning camera.

        Uses calc_mat (F @ inv(C_0) @ C_i) and the same intrinsics as
        project_points_to_image_batch, so the silhouettes show what the conditioning
        actually reads -- not merely what the input poses say.
        """
        from ..trainers.flow_matching.mixins.image_conditioned_proj import (
            ProjGridMV, compute_relative_calc_mat)
        from ..utils import mv_camera

        res = mv_camera.ALPHA_SIZE
        device = self.device

        F_mat = ProjGridMV(grid_resolution=2, image_resolution=64).front_view_transform_matrix
        calc_mat = compute_relative_calc_mat(
            views['transform_matrix'].to(device).float(),
            views['camera_distance'].to(device).float(),
            F_mat.to(device).float(),
        )[0]                                                        # [V, 4, 4]
        cam_angle = views['camera_angle_x'][0].float()
        mesh_scale = float(views['mesh_scale'])

        # preprocess_mesh puts the mesh in [-0.5, 0.5]^3; ProjGrid's world box is the
        # [-1, 1] grid over 2*mesh_scale, so world = preprocessed / mesh_scale.
        pre = self.preprocess_mesh(mesh)
        verts = torch.tensor(np.asarray(pre.vertices) / mesh_scale,
                             dtype=torch.float32, device=device)
        # ... then into the Blender frame ProjGrid projects from.
        rot = torch.tensor([[1., 0., 0.], [0., 0., -1.], [0., 1., 0.]], device=device)
        verts = verts @ rot.T
        faces = torch.tensor(np.asarray(pre.faces), dtype=torch.int32, device=device).contiguous()

        try:
            glctx = dr.RasterizeCudaContext()
        except Exception:
            glctx = dr.RasterizeGLContext()

        out = []
        near, far = 0.05, 100.0
        for i in range(calc_mat.shape[0]):
            w2c = torch.linalg.inv(calc_mat[i])
            vc = verts @ w2c[:3, :3].T + w2c[:3, 3]
            f = 1.0 / torch.tan(cam_angle[i] / 2).to(device)
            clip = torch.stack([
                f * vc[:, 0], f * vc[:, 1],
                -(far + near) / (far - near) * vc[:, 2] - 2 * far * near / (far - near),
                -vc[:, 2],
            ], dim=-1)[None].contiguous()
            rast, _ = dr.rasterize(glctx, clip, faces, resolution=[res, res])
            # nvdiffrast's row 0 is the bottom row; the masks have row 0 at the top.
            out.append(torch.flip(rast[0, ..., 3] > 0, dims=[0]))
        del glctx
        return out

    @torch.no_grad()
    def fit_mesh_orientation(self, mesh: trimesh.Trimesh, views: dict,
                             candidates: List[str] = None) -> Tuple[str, float, dict]:
        """
        Pick the reorientation whose silhouette best matches the views.

        The projected conditioning has no way to notice that a mesh is posed
        differently from the cameras: it just reads whatever the surface projects onto,
        so a mesh in the wrong frame samples background everywhere and the texture
        comes out near-black rather than failing. Scoring the silhouette against the
        view masks catches that before 3 minutes of sampling.

        Returns (name, mean IoU, {name: mean IoU}).
        """
        if views.get('alphas') is None:
            raise ValueError('views has no alpha masks; rebuild it with mv_camera.build_views')
        if candidates is None:
            candidates = list(self.MESH_ORIENTATIONS)

        masks = (views['alphas'][0].to(self.device) > 0.8)
        scores = {}
        for name in candidates:
            probe = mesh.copy()
            probe.apply_transform(self.MESH_ORIENTATIONS[name])
            ious = []
            for sil, m in zip(self._view_silhouettes(probe, views), masks):
                inter = (sil & m).sum().item()
                union = (sil | m).sum().item()
                ious.append(inter / union if union else 0.0)
            scores[name] = float(np.mean(ious))
            print(f'[Pixal3D MV] orientation {name!r}: silhouette IoU '
                  f'{", ".join(f"{v*100:.0f}%" for v in ious)} (mean {scores[name]*100:.0f}%)')

        best = max(scores, key=scores.get)
        return best, scores[best], scores

    @torch.inference_mode()
    def texture_mesh_pixal3d(
        self,
        mesh: trimesh.Trimesh,
        views: dict = None,
        image: Image.Image = None,
        camera_params: dict = None,
        seed: int = 42,
        tex_slat_sampler_params: dict = {},
        resolution: int = 1024,
        texture_size: int = 2048,
        texture_alpha_mode = 'OPAQUE',
        double_side_material = True,
        bake_on_vertices = False,
        use_custom_normals = False,
        mesh_cluster_threshold_cone_half_angle_rad = 60.0,
        sampler: str = 'euler',
        inpainting: str = 'telea',
        verbose: bool = False,
        dino_lock: float = 0.0,
        dino_substeps: int = 4,
        dino_foundation_cap: float = 0.92,
        mesh_orientation: str = 'auto',
    ):
        """
        Texture an existing mesh with Pixal3D, i.e. run only the tex stage of its
        cascade over a shape latent that came from a mesh instead of the shape stages.

        The mesh takes the place the generated shape latent normally holds: encode it
        with the shape VAE, then condition the tex denoiser on the same projected
        image features the cascade uses (get_proj_cond_shape*), at the grid resolution
        implied by `resolution`. `sample_tex_slat` concatenates the shape latent, so
        the tex denoiser sees exactly what it does mid-cascade.

        Unlike texture_mesh_multiview (global DINO features blended per view by a
        heuristic), the conditioning here is a geometric un-projection: the views need
        no blending, any number of them fuse by averaging, but the mesh has to be
        posed and scaled the way the cameras describe. preprocess_mesh normalises to a
        tight bbox in [-0.5, 0.5]^3, so if the views frame the object differently the
        grid samples off-surface and the texture washes out -- build the views with
        framing = auto (Trellis2 - Pixal3D MultiView Config), which fits the camera
        distance to the silhouette.

        Args:
            views: the bundle from mv_camera.build_views(); needs the multi-view
                weights (pipeline_mv.json). Takes precedence over `image`.
            image: single view, for the non-multi-view Pixal3D weights. Needs
                `camera_params` (camera_angle_x / distance / mesh_scale).
            mesh_orientation: how to rotate the mesh into the frame the cameras
                describe -- 'auto' fits it by silhouette (needs `views`), or name one
                of MESH_ORIENTATIONS. The output is rotated back, so the textured mesh
                comes out in the frame it went in.
        """
        if views is None and image is None:
            raise ValueError('texture_mesh_pixal3d needs either views or an image')
        if views is None and camera_params is None:
            raise ValueError('texture_mesh_pixal3d needs camera_params alongside a single image')
        if resolution % 16 != 0:
            raise ValueError(f'resolution must be a multiple of 16, got {resolution}')

        self.switch_samplers(sampler)

        if mesh_orientation == 'auto':
            if views is None:
                # Nothing to score a silhouette against.
                print("[Pixal3D] mesh_orientation 'auto' has no view masks to fit against on "
                      "the single-image path; assuming 'none'. A y-up glb needs '90 degrees' "
                      "-- set it explicitly if the texture comes out near-black.")
                mesh_orientation = 'none'
            else:
                mesh_orientation, iou, _ = self.fit_mesh_orientation(mesh, views)
                print(f'[Pixal3D] mesh_orientation auto -> {mesh_orientation!r} (IoU {iou*100:.0f}%)')
                if iou < 0.5:
                    print('[Pixal3D] Warning: even the best orientation matches the views '
                          f'only {iou*100:.0f}%. Check that the azimuths/elevations describe '
                          'these views, that the mesh is the object in them, and that '
                          'framing = auto.')
        if mesh_orientation not in self.MESH_ORIENTATIONS:
            raise ValueError(f'unknown mesh_orientation {mesh_orientation!r}; '
                             f'expected auto or one of {list(self.MESH_ORIENTATIONS)}')

        reorient = self.MESH_ORIENTATIONS[mesh_orientation]
        if mesh_orientation != 'none':
            mesh = mesh.copy()
            mesh.apply_transform(reorient)

        mesh = self.preprocess_mesh(mesh)
        seed_all(seed)

        shape_slat = self.encode_shape_slat(mesh, resolution)

        # The cascade drives the cond grid off the resolution it upsampled to; here
        # that is just the grid the encoder produced, i.e. resolution // 16.
        tex_grid_res = resolution // 16

        if views is not None:
            image_cond_model = self.load_pixal3d_mv_image_cond_tex_1024()
            cond = self.get_proj_cond_shape_mv(
                image_cond_model, views, shape_slat.coords,
                grid_resolution_override=tex_grid_res,
            )
            del image_cond_model
            if not self.keep_models_loaded:
                self.unload_pixal3d_mv_image_cond_tex_1024()
        else:
            images = list(image) if isinstance(image, (list, tuple)) else [image]
            image_cond_model = self.load_pixal3d_image_cond_tex_1024()
            cond = self.get_proj_cond_shape(
                image_cond_model, images, shape_slat.coords,
                camera_angle_x=camera_params['camera_angle_x'],
                distance=camera_params['distance'],
                mesh_scale=camera_params.get('mesh_scale', 1.0),
                grid_resolution_override=tex_grid_res,
            )
            del image_cond_model
            if not self.keep_models_loaded:
                self.unload_pixal3d_image_cond_tex_1024()

        torch.cuda.empty_cache()

        # Pixal3D has no 512 tex denoiser; the 1024 one is rope-based and is what the
        # cascade already runs at every resolution it upsamples to.
        self.load_tex_slat_flow_model_1024()
        tex_slat = self.sample_tex_slat(
            cond, self.models['tex_slat_flow_model_1024'],
            shape_slat, tex_slat_sampler_params,
            verbose = verbose,
            dino_lock = dino_lock,
            dino_substeps = dino_substeps,
            dino_foundation_cap = dino_foundation_cap
        )
        if not self.keep_models_loaded:
            self.unload_tex_slat_flow_model_1024()

        del cond
        torch.cuda.empty_cache()
        pbr_voxel = self.decode_tex_slat(tex_slat)
        torch.cuda.empty_cache()

        out_mesh, baseColorTexture, metallicRoughnessTexture = self.postprocess_mesh(mesh, pbr_voxel, resolution, texture_size, texture_alpha_mode, double_side_material, bake_on_vertices, use_custom_normals, mesh_cluster_threshold_cone_half_angle_rad, inpainting)

        # preprocess/postprocess_mesh are inverses, so the mesh comes back in the frame
        # it went into them; undo the reorientation too, to hand back the caller's frame.
        if mesh_orientation != 'none':
            out_mesh.apply_transform(np.linalg.inv(reorient))

        return out_mesh, baseColorTexture, metallicRoughnessTexture

    def get_coords_from_trimesh(self, mesh, resolution):
        vertices = torch.from_numpy(mesh.vertices).float()
        faces = torch.from_numpy(mesh.faces).long()
        
        voxel_indices, dual_vertices, intersected = o_voxel.convert.mesh_to_flexible_dual_grid(
            vertices.cpu(), faces.cpu(),
            grid_size=resolution,
            aabb=[[-0.5,-0.5,-0.5],[0.5,0.5,0.5]],
            face_weight=1.0,
            boundary_weight=0.2,
            regularization_weight=1e-2,
            timing=True,
        )
        
        coords = torch.cat([torch.zeros_like(voxel_indices[:, 0:1]), voxel_indices], dim=-1)                
        coords = coords.cpu()
        
        #print(coords)
        
        del voxel_indices
        del dual_vertices
        del intersected
        
        if self.low_vram:
            self._cleanup_cuda() 
        
        return coords;
        
    @torch.no_grad()        
    def sample_mesh_slat(
        self,
        mesh_slat,
        cond: dict,
        flow_model,
        resolution: int,
        sampler_params: dict = {},
        max_num_tokens: int = 49152,
        downsampling = 16,
        verbose: bool = False,
        dino_lock: float = 0.0,
        dino_substeps: int = 4,
        dino_foundation_cap: float = 0.92
    ) -> SparseTensor:
        # Upsample       
        self.load_shape_slat_decoder()
        print('Decoding mesh slat ...')
        if self.low_vram:
            self.models['shape_slat_decoder'].to(self.device)
            self.models['shape_slat_decoder'].low_vram = True
        hr_coords = self.models['shape_slat_decoder'].upsample(mesh_slat, upsample_times=4)
        if self.low_vram:
            self.models['shape_slat_decoder'].cpu()
            self.models['shape_slat_decoder'].low_vram = False
        hr_resolution = resolution
        
        if not self.keep_models_loaded:
            self.unload_shape_slat_decoder()
        
        #downsampling = 16
        lr_resolution = resolution
        # if hr_resolution == 512:
            # downsampling = 16
        # elif hr_resolution == 1024:
            # downsampling = 32
        # elif hr_resolution == 1536:
            # downsampling = 32
        
        while True:
            quant_coords = torch.cat([
                hr_coords[:, :1],
                ((hr_coords[:, 1:] + 0.5) / lr_resolution * (hr_resolution // downsampling)).int(),
            ], dim=1)
            coords = quant_coords.unique(dim=0)
            num_tokens = coords.shape[0]
            if num_tokens < max_num_tokens:
                if hr_resolution != resolution:
                    print(f"Due to the limited number of tokens, the resolution is reduced to {hr_resolution}.")
                print(f"Num tokens {num_tokens}")
                break
            hr_resolution -= 128
            if hr_resolution < 1024 and resolution >= 1024:
                hr_resolution = 1024
                print(f"Num tokens {num_tokens}")
                break
            if hr_resolution < 512:
                hr_resolution = 512
                print(f"Num tokens {num_tokens}")
                break
        
        coords_dev = coords.to(self.device)                                           
        # Sample structured latent
        noise = SparseTensor(
            feats=torch.randn(coords.shape[0], flow_model.in_channels, device=self.device),
            coords=coords_dev,
        )
        sampler_params = {**self.shape_slat_sampler_params, **sampler_params}
        if self.low_vram:
            flow_model.to(self.device)
        slat = self.shape_slat_sampler.sample(
            flow_model,
            noise,
            **cond,
            **sampler_params,
            verbose=verbose,
            dino_lock=dino_lock,
            dino_substeps=dino_substeps,
            dino_foundation_cap=dino_foundation_cap,
            tqdm_desc="Sampling shape SLat",
        ).samples
        if self.low_vram:
            flow_model.cpu()
            self._cleanup_cuda()                                

        std = torch.tensor(self.shape_slat_normalization['std'])[None].to(slat.device)
        mean = torch.tensor(self.shape_slat_normalization['mean'])[None].to(slat.device)
        slat = slat * std + mean
        
        del coords_dev
        if self.low_vram:
            cond = self._cond_cpu(cond)
            self._cleanup_cuda()

        return slat, hr_resolution        
    
    @torch.inference_mode()
    def refine_mesh(
        self,
        mesh: trimesh.Trimesh,
        image,
        seed: int = 42,
        shape_slat_sampler_params: dict = {},
        tex_slat_sampler_params: dict = {},
        resolution: int = 1024,
        max_num_tokens = 50000,
        generate_texture_slat = True,
        return_latent = False,
        downsampling = 16,
        use_tiled: bool = True,
        max_views: int = 4,
        sampler: str = 'euler',
        verbose: bool = False,
        dino_lock: float = 0.0,
        dino_substeps: int = 4,
        dino_foundation_cap: float = 0.92
    ):
        self.switch_samplers(sampler)
        
        mesh = self.preprocess_mesh(mesh)
        seed_all(seed)
        
        self.load_image_cond_model()
        
        if isinstance(image, (list, tuple)):
            images = list(image)
        else:
            images = [image]        
        
        if resolution == 512:
            cond = self.get_cond(images, 512, max_views = max_views)
        else:
            cond = self.get_cond(images, 1024, max_views = max_views)
        
        if not self.keep_models_loaded:
            self.unload_image_cond_model()        
        
        mesh_slat = self.encode_shape_slat(mesh, resolution)
        
        if resolution==512:
            self.unload_shape_slat_flow_model_1024()
            self.load_shape_slat_flow_model_512()            
            shape_slat, res = self.sample_mesh_slat(
                mesh_slat,
                cond,
                self.models['shape_slat_flow_model_512'],
                512,
                shape_slat_sampler_params,
                max_num_tokens,
                downsampling,
                verbose = verbose,
                dino_lock=dino_lock,
                dino_substeps=dino_substeps,
                dino_foundation_cap=dino_foundation_cap
            )
            
            if not self.keep_models_loaded:
                self.unload_shape_slat_flow_model_512()
            
            if generate_texture_slat:
                self.unload_tex_slat_flow_model_1024()
                self.load_tex_slat_flow_model_512()
                tex_slat = self.sample_tex_slat(
                    cond, self.models['tex_slat_flow_model_512'],
                    shape_slat, tex_slat_sampler_params,
                    verbose = verbose,
                    dino_lock=dino_lock,
                    dino_substeps=dino_substeps,
                    dino_foundation_cap=dino_foundation_cap
                )
            
            if not self.keep_models_loaded:
                self.unload_tex_slat_flow_model_512()                
        elif resolution == 1024:
            self.unload_shape_slat_flow_model_512()
            self.load_shape_slat_flow_model_1024()            
            shape_slat, res = self.sample_mesh_slat(
                mesh_slat,
                cond,
                self.models['shape_slat_flow_model_1024'],
                1024,
                shape_slat_sampler_params,
                max_num_tokens,
                downsampling,
                verbose = verbose,
                dino_lock=dino_lock,
                dino_substeps=dino_substeps,
                dino_foundation_cap=dino_foundation_cap
            )
            
            if not self.keep_models_loaded:
                self.unload_shape_slat_flow_model_1024()
            
            if generate_texture_slat:
                self.unload_tex_slat_flow_model_512()
                self.load_tex_slat_flow_model_1024()
                tex_slat = self.sample_tex_slat(
                    cond, self.models['tex_slat_flow_model_1024'],
                    shape_slat, tex_slat_sampler_params,
                    verbose = verbose,
                    dino_lock=dino_lock,
                    dino_substeps=dino_substeps,
                    dino_foundation_cap=dino_foundation_cap
                )
            
            if not self.keep_models_loaded:
                self.unload_tex_slat_flow_model_1024()
        elif resolution == 1536:
            self.unload_shape_slat_flow_model_512()
            self.load_shape_slat_flow_model_1024()            
            shape_slat, res = self.sample_mesh_slat(
                mesh_slat,
                cond,
                self.models['shape_slat_flow_model_1024'],
                1536,
                shape_slat_sampler_params,
                max_num_tokens,
                downsampling,
                verbose = verbose,
                dino_lock=dino_lock,
                dino_substeps=dino_substeps,
                dino_foundation_cap=dino_foundation_cap
            )
            
            if not self.keep_models_loaded:
                self.unload_shape_slat_flow_model_1024()
            
            if generate_texture_slat:
                self.unload_tex_slat_flow_model_512()
                self.load_tex_slat_flow_model_1024()
                tex_slat = self.sample_tex_slat(
                    cond, self.models['tex_slat_flow_model_1024'],
                    shape_slat, tex_slat_sampler_params,
                    verbose = verbose,
                    dino_lock=dino_lock,
                    dino_substeps=dino_substeps,
                    dino_foundation_cap=dino_foundation_cap
                )
            
            if not self.keep_models_loaded:
                self.unload_tex_slat_flow_model_1024()                 
                
        torch.cuda.empty_cache()
        if generate_texture_slat:
            out_mesh = self.decode_latent(shape_slat, tex_slat, res, use_tiled=use_tiled)
        else:
            out_mesh = self.decode_latent(shape_slat, None, res, use_tiled=use_tiled)
        torch.cuda.empty_cache()
        
        if return_latent:
            if generate_texture_slat:
                return out_mesh, (shape_slat, tex_slat, res)
            else:
                return out_mesh, (shape_slat, None, res)
        else:
            return out_mesh      
            
    @torch.inference_mode()
    def run_pixal3d(
        self,
        image: Image.Image,
        camera_params: dict,
        num_samples: int = 1,
        seed: int = 42,
        sparse_structure_sampler_params: dict = {},
        shape_slat_sampler_params: dict = {},
        tex_slat_sampler_params: dict = {},
        preprocess_image: bool = False,
        return_latent: bool = False,
        pipeline_type: Optional[str] = None,
        max_num_tokens: int = 49152,
        generate_texture_slat: bool = False
    ) -> List[MeshWithVoxel]:
        """
        Run the Pixal3D pipeline (proj mode, cascade).

        Args:
            image (Image.Image): The image prompt.
            camera_params (dict): Camera parameters with keys:
                - camera_angle_x (float): Horizontal FOV in radians.
                - distance (float): Camera distance.
                - mesh_scale (float): Mesh scale factor.
            num_samples (int): The number of samples to generate.
            seed (int): The random seed.
            sparse_structure_sampler_params (dict): Additional parameters for the sparse structure sampler.
            shape_slat_sampler_params (dict): Additional parameters for the shape SLat sampler.
            tex_slat_sampler_params (dict): Additional parameters for the texture SLat sampler.
            preprocess_image (bool): Whether to preprocess the image.
            return_latent (bool): Whether to return the latent codes.
            pipeline_type (str): The type of the pipeline. Options: '1024_cascade', '1536_cascade'.
            max_num_tokens (int): The maximum number of tokens to use.
        """
        # Check pipeline type
        if pipeline_type == '1536_cascade':
            hr_resolution = 1536
        else:
            hr_resolution = 1024

        # Extract camera params
        camera_angle_x = camera_params['camera_angle_x']
        distance = camera_params['distance']
        mesh_scale = camera_params.get('mesh_scale', 1.0)
        
        if preprocess_image:
            image = self.preprocess_image(image)
        torch.manual_seed(seed)

        # ---- Stage 1: Sparse Structure (proj) ----
        image_cond_model = self.load_pixal3d_image_cond_ss()
        cond_ss = self.get_proj_cond_ss(
            [image],
            camera_angle_x=camera_angle_x,
            distance=distance,
            mesh_scale=mesh_scale,
            image_cond_model=image_cond_model
        )
        del image_cond_model
        if not self.keep_models_loaded:
            self.unload_pixal3d_image_cond_ss()        
        ss_res = 32
        self.load_sparse_structure_model()
        coords = self.sample_sparse_structure(
            cond_ss, ss_res,
            num_samples, sparse_structure_sampler_params
        )
        if not self.keep_models_loaded:
            self.unload_sparse_structure_model()         
        del cond_ss
        torch.cuda.empty_cache()

        # ---- Stage 2: Shape LR 512 (proj) ----
        image_cond_model = self.load_pixal3d_image_cond_shape_512()
        cond_shape_lr = self.get_proj_cond_shape(
            image_cond_model, [image], coords,
            camera_angle_x=camera_angle_x,
            distance=distance,
            mesh_scale=mesh_scale,
        )
        del image_cond_model
        if not self.keep_models_loaded:
            self.unload_pixal3d_image_cond_shape_512()        
        self.load_shape_slat_flow_model_512()
        lr_slat = self.sample_shape_slat(
            cond_shape_lr, self.models['shape_slat_flow_model_512'],
            coords, shape_slat_sampler_params
        )
        if not self.keep_models_loaded:
            self.unload_shape_slat_flow_model_512()        
        del cond_shape_lr
        torch.cuda.empty_cache()

        # ---- Stage 3a: Upsample LR → HR ----
        self.load_shape_slat_decoder()
        if self.low_vram:
            self.models['shape_slat_decoder'].to(self.device)
            self.models['shape_slat_decoder'].low_vram = True
        hr_coords = self.models['shape_slat_decoder'].upsample(lr_slat, upsample_times=4)
        if self.low_vram:
            self.models['shape_slat_decoder'].cpu()
            self.models['shape_slat_decoder'].low_vram = False

        if not self.keep_models_loaded:
            self.unload_shape_slat_decoder()

        lr_resolution = 512
        actual_hr_resolution = hr_resolution
        while True:
            grid_res = actual_hr_resolution // 16
            quant_coords = torch.cat([
                hr_coords[:, :1],
                ((hr_coords[:, 1:] + 0.5) / lr_resolution * (grid_res - 1)).round().int(),
            ], dim=1)
            hr_coords_unique = quant_coords.unique(dim=0)
            num_tokens = hr_coords_unique.shape[0]
            if num_tokens < max_num_tokens or actual_hr_resolution == 1024:
                break
            actual_hr_resolution -= 128

        actual_grid_res = actual_hr_resolution // 16
        del lr_slat, hr_coords, quant_coords
        torch.cuda.empty_cache()

        # ---- Stage 3b: Shape HR (proj) ----
        image_cond_model = self.load_pixal3d_image_cond_shape_1024()
        cond_shape_hr = self.get_proj_cond_shape(
            image_cond_model, [image], hr_coords_unique,
            camera_angle_x=camera_angle_x,
            distance=distance,
            mesh_scale=mesh_scale,
            grid_resolution_override=actual_grid_res,
        )
        del image_cond_model
        if not self.keep_models_loaded:
            self.unload_pixal3d_image_cond_shape_1024()     

        self.load_shape_slat_flow_model_1024()        
            
        noise_hr = SparseTensor(
            feats=torch.randn(hr_coords_unique.shape[0], self.models['shape_slat_flow_model_1024'].in_channels).to(self.device),
            coords=hr_coords_unique,
        )
        sampler_params_hr = {**self.shape_slat_sampler_params, **shape_slat_sampler_params}
                
        flow_model_hr = self.models['shape_slat_flow_model_1024']
        if self.low_vram:
            flow_model_hr.to(self.device)
        hr_slat = self.shape_slat_sampler.sample(
            flow_model_hr,
            noise_hr,
            **cond_shape_hr,
            **sampler_params_hr,
            verbose=True,
            tqdm_desc=f"Sampling HR shape SLat (proj, {actual_hr_resolution})",
        ).samples
        if self.low_vram:
            flow_model_hr.cpu()
        std = torch.tensor(self.shape_slat_normalization['std'])[None].to(hr_slat.device)
        mean = torch.tensor(self.shape_slat_normalization['mean'])[None].to(hr_slat.device)
        shape_slat = hr_slat * std + mean
        del flow_model_hr
        if not self.keep_models_loaded:
            self.unload_shape_slat_flow_model_1024()        
        del cond_shape_hr, noise_hr, hr_slat, hr_coords_unique
        torch.cuda.empty_cache()

        if generate_texture_slat:
            # ---- Stage 4: Texture (proj) ----
            image_cond_model = self.load_pixal3d_image_cond_tex_1024()
            
            tex_grid_res = actual_hr_resolution // 16
            cond_tex = self.get_proj_cond_shape(
                image_cond_model, [image], shape_slat.coords,
                camera_angle_x=camera_angle_x,
                distance=distance,
                mesh_scale=mesh_scale,
                grid_resolution_override=tex_grid_res,
            )
            
            if not self.keep_models_loaded:
                self.unload_pixal3d_image_cond_tex_1024()            
            
            self.load_tex_slat_flow_model_1024()
            
            tex_slat = self.sample_tex_slat(
                cond_tex, self.models['tex_slat_flow_model_1024'],
                shape_slat, tex_slat_sampler_params
            )
            
            if not self.keep_models_loaded:
                self.unload_tex_slat_flow_model_1024()             
            
            del cond_tex
            torch.cuda.empty_cache()

        # ---- Stage 5: Decode ----
        res = actual_hr_resolution
        
        if generate_texture_slat:
            out_mesh = self.decode_latent(shape_slat, tex_slat, res)
        else:
            out_mesh = self.decode_latent(shape_slat, None, res)
        if return_latent:
            return out_mesh, (shape_slat, tex_slat, res)
        else:
            return out_mesh            